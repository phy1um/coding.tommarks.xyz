
# Litte Men

This is a simple C/SDL2 test by Tom Marks from 2016. It has been archived for prosterity.
The original Windows build scripts and final binaries are included in the `bin/` folder.

In 2024 a Linux build was added as part of uploading this to my website. This may have
broken the original Windows build scripts, I do not have a Windows computer to check
any more.
 
Visit my website @ https://coding.tommarks.xyz 
