#ifndef PH__SRC_WORLD_H
#define PH__SRC_WORLD_H

#define WORLD_WIDTH 600
#define WORLD_HEIGHT 400

#endif