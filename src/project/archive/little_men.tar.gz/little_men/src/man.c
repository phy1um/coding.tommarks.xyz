#define PH__SRC_MAN_C
#include <math.h>

#include "man.h"
#include "ashare/dbg.h"
#include "ashare/share_base.h"
#include "world.h"


static int Man_getNeighbors(Man_t *man, int *count);

// static values~
const SDL_Rect RECT_BOUNDS = {.x = MAN_BOUNDS, .y = MAN_BOUNDS, 
	.w = WORLD_WIDTH - (2*MAN_BOUNDS), .h = WORLD_HEIGHT - (2*MAN_BOUNDS)};

static int man_counter = 0;
static int man_maximum = MAN_MAX_DEFAULT;
static int man_alloc_head = 0;
static Man_t* man_list = NULL;

const int MAN_HEALTH_BAR_OFFSETX = -1 * ((MAN_HEALTH_BAR_WIDTH - MAN_WIDTH) / 2);

// public functions first~

// get the play area that men are bound to
const SDL_Rect * Man_getBounds(void)
{
	return &RECT_BOUNDS;
error:
	return NULL;
}

// count of men
int Man_count(void)
{
	return man_counter;
}

// set the maximum number of allocated men, only before _init
void Man_setMaximum(int max)
{
	man_maximum = max;
}

// initialise man_list
int Man_init(void)
{
	if(man_list) {
		log_warn("%s called when Man array was already initialised.", __func__);
		free(man_list);
	}
	
	man_list = calloc(man_maximum, sizeof(Man_t));
	check_mem(man_list);
	
	// more??
	return 0;
error:
	return -1;
}

// get man by id, but check it like a motherfucker first
Man_t *Man_get(int id) 
{
	check(man_list != NULL, "Cannot get Man - core array is NULL!");
	check(id >= 0, "id entered was invalid: %d", id);
	check(id <= man_alloc_head, 
		"id entered was too big! id:%d, Alloc head:%d, Max:%d", id, 
		man_alloc_head, man_maximum);
		
	return &(man_list[id]);
error:
	return NULL;
}


Man_t *Man_getList(int *alloc_head)
{
	check(man_list != NULL, "Cannot get the list of Men, NULL ptr.");
	if( alloc_head ) 
		*alloc_head = man_alloc_head;
		
	return man_list;
error:
	return NULL;
}


void Man_cleanAll(void)
{
	int i;
	Man_t* tgt;
	for( i = 0; i < man_alloc_head; i++ ) {
		tgt = Man_get(i);
		if( tgt->local_list )
			free(tgt->local_list);
		
		if( tgt->name )
			free(tgt->name);
		
	}
	
	free(man_list);
	return;
}


int Man_create(int sx, int sy, int hp, int pow, int spd, int type, int col,
	int mv_intent, char *name)
{
	// do we have room to allocate another man
	int alloc_head_tmp = man_alloc_head;
	int counter_tmp = man_counter;
	check(man_alloc_head < man_maximum, "Out of room for Men!");
	Man_t* tgt = Man_get(man_alloc_head);
	// did we sucessfully get a man from man_list
	check(tgt != NULL, "Man is NULL, error in main man array.");
	// save these values, just in case we need to roll back
	
	
	/* init Man_t
	*tgt = {
		.x = sx, .y = sy, .health = hp, .power = pow, .speed = spd,
		.type = type, .colour = col, .name = name
	};*/
	
	tgt->x = sx;
	tgt->y = sy;
	tgt->health = hp;
	tgt->init_health = hp;
	tgt->power = pow;
	tgt->speed = spd;
	tgt->type = type;
	tgt->colour = col;
	tgt->name = name;
	
	tgt->was_hit = 0;
	
	man_counter++;
	tgt->id = man_alloc_head++;
	//initialise direction data
	tgt->direction = Util_Random(DIR_MAX - 1);
	tgt->dir_intent = mv_intent;
	tgt->dir_time = 0;
	tgt->dir_intent_rnd = Util_Random(tgt->dir_intent);
	
	tgt->anim_frame = 0;
	tgt->anim_counter = 0;
	// get diagonal move speed
	//tgt->dspeed = (float) sqrt(4*spd);
	tgt->dspeed = tgt->speed * 0.707;
	
	tgt->local_list = calloc(man_maximum, sizeof(int));
	check_mem(tgt->local_list);
	
	tgt->dead = 0;
	tgt->last_hit = MAN_ATTACK_TIMER;
	return 0;
	
error:
	// roll these values back, and hope it goes better next time?
	man_alloc_head = alloc_head_tmp;
	man_counter = counter_tmp;
	log_flush();
	return -1;
}


int Man_update(Man_t *man)
{
	int rc = 0;
	// move
	check(man != NULL, "Cannot pass NULL man to update.");
	rc = Man_move(man);
	check(rc == 0, "Could not move Man!");
	// if we've been going one way for too long..
	if(man->dir_time > man->dir_intent_rnd || man->dir_time < 0) {
		// get a new direction
		man->direction = Util_Random(DIR_MAX);
		// set a new timer
		man->dir_intent_rnd = 110 - Util_Random(man->dir_intent);
		man->dir_time = 0;
	}
	
	
	// deal with passers by
	if(man->last_hit < 0) {
		int others;
		rc = Man_getNeighbors(man, &others);
		check(rc == 0, "Failed to get neighbors.");
		
		// for each id we just had loaded into local_list, get that 
		//  man and hit them!
		if( man->id == 0 ) {
			debug("Starting neighbor loop, count: %d", (int)others);
		}
		
		log_flush();
		int i;
		Man_t *tgt;
		if( others > 0 ) {
			for( i = 0; i < others; i++ ) {
				tgt = Man_get(man->local_list[i]);
				check(tgt != NULL, 
					"Could not get target Man from local neighbor list, i:%d.",
					i );
				if(tgt->colour != man->colour) {
					rc = Man_strike(man, tgt);
					check(rc == 0, "Failed to attack your fellow Man.");
				}
			}
		}
		
		man->last_hit = MAN_ATTACK_TIMER;
	}
	
	#ifndef NDEBUG
	log_flush();
	#endif
	
	//debug("Anim...");
	// anim
	if( man->anim_counter > MAN_ANIM_PAUSE ) {
		man->anim_counter = 0;
		man->anim_frame++;
		if( man->anim_frame >= MAN_ANIM_FRAMES )
			man->anim_frame = ANIM_FRAME1;
		
	}
	
	// see if i need to die
	if( man->health < 0 ) { Man_die(man); }
	
	// update counters
	man->dir_time++;
	man->anim_counter++;
	man->last_hit--;
	
	if(man->last_hit != 0)
		man->last_hit = 0;
	
	return 0;

error:
	log_warn("Man update failed.");
	return -1;
}


int Man_getSpriteBox(Man_t *man, SDL_Rect *out, int *px, int *py)
{
	check(out != NULL, "SDL_Rect param cannot be NULL!");
	check(man != NULL, "Man nust not be NULL!");
	// if we're not moving, just return the standing animation frame
	if ( man->direction == DIR_STILL ) {
		out->x = man->type * MAN_WIDTH * MAN_TRUE_FRAMES;
	}
	
	else {
		// frames animate horizontally, colours are done vertically
		//  see res/men.bmp to have any hope of understanding this :D
		switch(man->anim_frame) {
			case ANIM_FRAME1:
			// fallthrough, these are the same frame
			case ANIM_FRAME3:
				out->x = man->type * MAN_WIDTH * MAN_TRUE_FRAMES;
				break;
			case ANIM_FRAME2:
				out->x = (man->type * MAN_WIDTH * MAN_TRUE_FRAMES) + MAN_WIDTH;
				break;
			case ANIM_FRAME4:
				out->x = (man->type * MAN_WIDTH * MAN_TRUE_FRAMES) + (2*MAN_WIDTH);
				break;
			default:
				check(0, "Invalid animation frame number :(");
				break;
		}
		
	}
	
	out->y = MAN_HEIGHT * man->colour;
	// we only care about rendering to the pixel, but can store information about 
	//  being "between" them
	*px = (int) man->x;
	*py = (int) man->y;
	
	return 0;
	
error:
	log_flush();
	return -1;
}


int Man_getHealthBox(Man_t *man, SDL_Rect *sprite_box, SDL_Rect *screen_box)
{
	check(man != NULL, "Man must not be NULL.");
	check(sprite_box != NULL && screen_box != NULL, 
		"Invalid SDL_Rect parameters - NULL ptr caught.");
	
	int size = MAN_HEALTH_BAR_WIDTH * ( man->health / man->init_health );
	if( size <= 0 ) {
		if( man->health >= 0 ) {
			size = 1;
		}
		else
			return 0;
	}
	
	sprite_box->w = size;
	screen_box->w = size;
	
	screen_box->y = ((int) man->y) + MAN_HEALTH_BAR_OFFSETY;
	screen_box->x = ((int) man->x) + MAN_HEALTH_BAR_OFFSETX;
return 0;
	
error:
	return -1;
}




// static functions! ~

static int Man_move(Man_t *man)
{
	check(man != NULL, "Cannot pass a Man that is NULL.");
	
	float dx = 0, dy = 0;
	// use either speed or dspeed, depending on if we're going
	//  diagonally or not
	switch(man->direction) {
		case DIR_LEFT:
			dx = -(man->speed);
			break;
		case DIR_RIGHT:
			dx = man->speed;
			break;
		case DIR_UP:
			dy = -(man->speed);
			break;
		case DIR_DOWN:
			dy = man->speed;
			break;
		case DIR_UPLEFT:
			dx = -(man->dspeed);
			dy = -(man->dspeed);
			break;
		case DIR_UPRIGHT:
			dx = man->dspeed;
			dy = -(man->dspeed);
			break;
		case DIR_DOWNLEFT:
			dx = -(man->dspeed);
			dy = man->dspeed;
			break;
		case DIR_DOWNRIGHT:
			dx = man->dspeed;
			dy = man->dspeed;
			break;
		case DIR_STILL:
			break;
			
		default:
			check(0, "Invalid direction passed to move..");
			break;
	}
	
	float next_x = man->x + dx;
	float next_y = man->y + dy;
	// check that we're in-bounds
	if( next_x > MAN_BOUNDS && next_x + MAN_WIDTH < RECT_BOUNDS.w + MAN_BOUNDS && 
	 next_y > MAN_BOUNDS && next_y + MAN_HEIGHT < RECT_BOUNDS.h + MAN_BOUNDS ) 
	{
		man->x = next_x;
		man->y = next_y;
	}
	// if not, stand still for a bit then choose a new direction
	else {
		man->direction = Man_reverseDirection(man->direction);
		int time_diff = man->dir_intent_rnd - man->dir_time;
		man->dir_time += time_diff/2;
		//man->dir_intent_rnd = 110 - Util_Random(man->dir_intent);
	}
	
	return 0;
	
error:
	return -1;
	
}


static int Man_getNeighbors(Man_t *man, int *count)
{
	check(man != NULL, "Cannot pass a Man that is NULL.");
	check(man->local_list != NULL, "Man's Local List is NULL.");
	int i;
	Man_t *tgt = NULL;
	if(man->id == 0) {
		debug("Count pre-setting: %d", *count);
	}
	*count = 0;
	if( man->id == 0){ 
		debug("Count post-setting: %d", *count);
	}
	
	// for each man ...
	for( i = 0; i < man_alloc_head; i++ ) {
		// who is still alive...
		tgt = Man_get(i);
		check(man != NULL, "Man ID:%d is NULL, abort.", i);
		
		if( tgt->dead == 0 && man->id != tgt->id ) {
			// if distance is less than 100px...
			float dst = (float) sqrt ( (man->x - tgt->x)*(man->x - tgt->x) + 
				(man->y - tgt->y)*(man->y - tgt->y) );
			
			#ifndef NDEBUG
			if( man->id == 0 ) {
				debug("  Man found alive: #%d, dist:%f", tgt->id, dst);
				debug("  x:%f, y:%f   otherx:%f, othery:%f", 
					man->x, man->y, tgt->x, tgt->y);
			}
			#endif
			log_flush();
			if( dst < 100 ) {
				// add id to man's local_list
				#ifndef NDEBUG
				if( man->id == 0 ) {
					debug("Putting man in list: #%d, place:%d", tgt->id, *count);
					log_flush();
				}
				#endif
				
				check(*count >= 0 && *count < man_alloc_head, "Invalid value of count: %d!", *count);
				man->local_list[(*count)] = tgt->id;
				(*count)++;
			}
		}
	}
	
	return 0;
error:
	return -1;
}


static int Man_strike(Man_t *me, Man_t *other)
{
	check(other != NULL && me != NULL, "Must pass valid Men to function!");
	
	if(other->last_hit == 0) {
		other->health -= me->power;
		other->last_hit = 1;
	}
	return 0;
error:
	return -1;
}

// doesn't remove us, do: if (man->hp < 0)
static int Man_die(Man_t *me)
{
	check(me != NULL, "Cannot kill what does not exist.");
	man_counter--;
	me->dead = 1;
	if( me->name ) {
		log_info("%s#%d has died. Blurgh!", me->name, me->id);
	} 
	else {
		log_info("Man#%d has died. Blurgh!", me->id);
	}
	return 0;
error:
	return -1;
}


static DIR_T Man_reverseDirection(DIR_T direction)
{
	switch (direction) {
		case DIR_LEFT:
			return DIR_RIGHT;
		case DIR_RIGHT:
			return DIR_LEFT;
		case DIR_UP:
			return DIR_DOWN;
		case DIR_DOWN:
			return DIR_UP;
			
		case DIR_UPLEFT:
			return DIR_DOWNRIGHT;
		case DIR_UPRIGHT:
			return DIR_DOWNLEFT;
		case DIR_DOWNLEFT:
			return DIR_UPRIGHT;
		case DIR_DOWNRIGHT:
			return DIR_UPLEFT;
		
		default:
			return DIR_STILL;
	}
	
}
