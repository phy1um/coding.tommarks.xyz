#include <SDL2/SDL.h>

#include "share_utils.h"
#include "share_base.h"
#include "dbg.h"
#include <stdlib.h>
#include <time.h>

const_bstring RESOURCE_PATH;


static int File_InitialiseResourcePath()
{
	if( RESOURCE_PATH ) {
		return 1;
	}
	
	const char * sdl_path = SDL_GetBasePath();
	check(sdl_path, "SDL could not setup the base path on this system.");
	
	bstring temp_path = bfromcstr(SDL_GetBasePath());
	check(bfindreplace(temp_path, bfromcstr("bin"), bfromcstr("res"), 0) == BSTR_OK, "bstring find and replace failed.");
	
	RESOURCE_PATH = bstrcpy(temp_path);
	bdestroy(temp_path);
	return 0;
	
error:
	return -1;
	if(temp_path) bdestroy(temp_path);
}



int Util_CString_Convert(bstring in, char **out)
{
	if(*out) {free(*out);}
	check(in != NULL, "Invalid input: bstring input is NULL.");
	
	
	int len = blength(in);
	*out = malloc( (len+1) * sizeof(char) );
	*out = bdata(in);
	(*out)[len] = '\0';
	return 0;
	
error:
	if(*out) free(*out);
	return -1;
}


bstring File_GetResource_cstr(const char *sub_dir, bstring *out)
{
	
	if ( !RESOURCE_PATH ) {
		int r =  File_InitialiseResourcePath();
		if ( r ) {
			sentinel("Resource data path could not be initialised D:");
		}
	}
	
	check(sub_dir, "Invalid input: path string cannot be NULL.");
	
	if(*out) {
		log_warn("Out bstring exists, destroying to avoid memory leaks");
		bdestroy(*out);
	}
	
	*out = bstrcpy(RESOURCE_PATH);
	check(*out, "Failed to copy RESOURCE_PATH.");
	int rc = bcatcstr(*out, sub_dir);
	check((*out != NULL) && (rc == BSTR_OK), "Error appending to resource path. Given dir: %s", sub_dir);
	return *out;
	
error:
	return NULL;
}


bstring File_GetResource(bstring sub_dir, bstring *out)
{
	
	if ( !RESOURCE_PATH ) {
		int r = File_InitialiseResourcePath();
		if ( r ) {
			sentinel("Resource data path could not be initialised D:");
		}
	}
	
	check(sub_dir, "Invalid input: path bstring cannot be NULL.");
	
	if(*out) {
		log_warn("Out bstring exists, destroying to avoid memory leaks");
		bdestroy(*out);
	}
	
	*out = bstrcpy(RESOURCE_PATH);
	check(*out, "Failed to copy RESOURCE_PATH");
	int rc = bconcat(*out, sub_dir);
	check((*out != NULL) && (rc == BSTR_OK), "Error appending to resource path. Given dir: %s", sub_dir);
	
	/*
	char *t = NULL;
	rc = Util_CString_convert(out, &t);
	check(rc == 0, "Failed to convert..");
	log_info("Info: %s", t);*/
	
	return *out;
	
error:
	*out = NULL;
	return NULL;
}



int Util_Random(int max)
{
	float rn = (rand()-1) / (float)RAND_MAX;
	return (rn * max);
}


int Util_SeedRandom(void)
{
	srand(time(0));
	return 0;
}
