#ifndef PH__SRC_MAN_H__
#define PH__SRC_MAN_H__

#include <SDL2/SDL.h>

#define MAN_MAX_DEFAULT 100

#define MAN_WIDTH 10
#define MAN_HEIGHT 17

#define MAN_HEALTH_BAR_WIDTH 20
#define MAN_HEALTH_BAR_OFFSETY -3
#define MAN_HEALTH_BAR_SPRITE_OFFSET MAN_HEIGHT*8
#define MAN_HEALTH_BAR_SPRITE_SIZE 2

// how long to wait between animation frames
#define MAN_ANIM_PAUSE 5
// define frame names for neatness
#define MAN_ANIM_FRAMES 4
	#define ANIM_FRAME1 0
	#define ANIM_FRAME2 1
	#define ANIM_FRAME3 2
	#define ANIM_FRAME4 3

// actual number of frames without repeats
#define MAN_TRUE_FRAMES 3

// this is how many pixels aroudn the edge of the screne our Men can't go to
#define MAN_BOUNDS 1
// 
#define DIR_T int
	#define DIR_LEFT 0
	#define DIR_RIGHT 1
	#define DIR_UP 2
	#define DIR_DOWN 3
	#define DIR_UPLEFT 4
	#define DIR_UPRIGHT 5
	#define DIR_DOWNLEFT 6
	#define DIR_DOWNRIGHT 7
	#define DIR_UKN -1
	#define DIR_STILL 8
	#define DIR_MAX 9

#define MAN_ATTACK_TIMER 11
	
typedef struct man_data_s {
	// position data
	float x;
	float y;
	// health > 0 == alive
	int health;
	// initial health, for health bar drawing
	int init_health;
	// how much damage i do to others
	int power;
	// how many pixels per second i move
	int speed;
	// speed on a diagonal
	float dspeed;
	
	int last_hit;
	
	// current animation frame
	int anim_frame;
	// counter for when to increment anim_frame
	int anim_counter;
	
	// how strongly do we go in directions?
	int dir_intent;
	// how long have we been going in the current dir
	int dir_time;
	// current man direction
	DIR_T direction;
	// randomised intent, >= 0 < dir_intent
	// we check dir_time against this and
	// refresh it for each new direction.
	// this is our actual direction timer!
	int dir_intent_rnd;
	
	// can be NULL
	char *name;
	
	// which sprite type to use (x)
	int type;
	// which sprite colour row (y)
	int colour;
	
	int was_hit;
	
	// used for storing info about neighboring men
	int *local_list;
	// am i alive
	int dead;
	// unique id
	int id;
} Man_t;


// "global" function definitions
const SDL_Rect * Man_getBounds(void);
int Man_count(void);
void Man_setMaximum(int max);
int Man_init(void);
// man getters
Man_t* Man_get(int id);
Man_t* Man_getList(int *alloc_head);
void Man_cleanAll(void);

// man functions
int Man_create(int sx, int sy, int hp, int pow, 
	int spd, int type, int col, int mv_intent, char *name);
	
int Man_update(Man_t *man);
int Man_getSpriteBox(Man_t *man, SDL_Rect *out, int *px, int *py);
int Man_getHealthBox(Man_t *man, SDL_Rect *sprite_box, SDL_Rect *screen_box);

// static functions for source file
#ifdef PH__SRC_MAN_C
static int Man_move(Man_t *man);
static int Man_getNeightbors(Man_t *man, int *count);
static int Man_strike(Man_t *me, Man_t *other);
static int Man_die(Man_t *me);
static DIR_T Man_reverseDirection(DIR_T direction);
#endif

#define Man_getID(man) ((man)->id)

#endif
