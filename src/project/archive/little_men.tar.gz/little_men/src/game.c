
#include <SDL2/SDL.h>
#include <stdio.h>

#include "ashare/bstrlib.h"
#include "ashare/share_utils.h"
#include "ashare/share_base.h"

#include "man.h"
#include "world.h"

const int WINDOW_WIDTH = WORLD_WIDTH;
const int WINDOW_HEIGHT = WORLD_HEIGHT;
const char *WINDOW_TITLE = "Little Men!";

#define FRAMES_PER_SEC 30
const uint32_t TIMER_RES = 1000/FRAMES_PER_SEC;

FILE *log_file;

int init_window(SDL_Window **gWnd, SDL_Surface **gScreen);
int load_image(SDL_Surface **gTarget, const char *path);

#define LOG_FRAME_DELAY 15

#ifdef NDEBUG
#define LOG_FILE_NAME "session.log"
#else
#define LOG_FILE_NAME "debug.log"
#endif


#ifdef _WIN32
#include <windows.h>
int WINAPI WinMain(HINSTANCE hI, HINSTANCE hP, LPSTR lpCmdLine, int CmdShow)
#else
int main()
#endif
{

	int rc =0, loop =0, log_frames =0, pause =0;
	SDL_Window *window = NULL;
	SDL_Surface *screen = NULL, *bg = NULL, *man_sheet = NULL;
	SDL_Event ev;
	
	Util_SeedRandom();
	
	log_init(LOG_FILE_NAME, "w");

	
	log_info("Starting...");
	log_flush();
	
	rc = init_window(&window, &screen);
	check(rc == 0, "Could not initialise SDL systems.");
	
	log_info("Loading first image:");
	rc = load_image(&bg, "back2.bmp");
	check(rc == 0, "Could not load back.bmp!");
	log_info("Loading second image:");
	rc = load_image(&man_sheet, "men.bmp");
	check(rc == 0, "Could not load men.bmp!");
	
	// set transparency
	SDL_PixelFormat *fmt = (man_sheet)->format;
	Uint32 px = SDL_MapRGB(fmt, 0, 255, 0);
	SDL_SetColorKey(man_sheet, SDL_TRUE, px);
	
	log_flush();
	
	rc = Man_init();
	check(rc == 0, "Fialed to initialise Men!");
	
	
	/*
	log_info("Making a man.");
	rc = Man_create(300, 200, 100, 5, 3, 0, Util_Random(8), 60, "Bob");
	check(rc == 0, "Failed to make Bob D:");
	log_info("Making another man..");
	Man_create(100, 100, 50, 10, 2, 1, Util_Random(8), 30, "Bill");
	check(rc == 0, "Failed to make Bill D:");
	*/
	for(int i = 0; i < MAN_MAX_DEFAULT; i++) {
		Man_create(
			200 + Util_Random(100), 100 + Util_Random(100), Util_Random(50) + 20,
			Util_Random(1) + 4, Util_Random(3) + 1, Util_Random(3), Util_Random(8),
			Util_Random(60) + 10, "Billy");
	}
	
	loop = 1;
	uint32_t next_frame = 1;
	Man_t *men = NULL;
	int man_list_size = 0, i = 0;
	int draw_x = 0, draw_y = 0;
	SDL_Rect draw_box = {0};
	draw_box.w = MAN_WIDTH;
	draw_box.h = MAN_HEIGHT;
	SDL_Rect screen_box = {0};
	screen_box.w = MAN_WIDTH;
	screen_box.h = MAN_HEIGHT;
	
	SDL_Rect health_bar_sprite = {0};
	health_bar_sprite.h = MAN_HEALTH_BAR_SPRITE_SIZE;
	health_bar_sprite.y = MAN_HEALTH_BAR_SPRITE_OFFSET;
	health_bar_sprite.x = 0;
	
	SDL_Rect health_bar_screen = {0};
	health_bar_screen.h = MAN_HEALTH_BAR_SPRITE_SIZE;
	
	debug("About to start main loop, quick stats!");
	#ifndef NDEBUG
	Man_getList(&man_list_size);
	debug("SDL time: %d; Men allocated: %d", SDL_GetTicks(), man_list_size);
	//man_list_size = 0;
	
	debug("Testing a hypothesis!");
	Man_t *test = Man_get(0);
	test->health;
	debug("Man_get() works ok!");
	#endif
	
	log_flush();
	while(loop) {
		while( SDL_PollEvent(&ev) ) {
			if(ev.type == SDL_QUIT) {
				loop = 0;
				log_info("Quit message recieved.");
				log_flush();
			}
			
			else if(ev.type == SDL_KEYDOWN) {
				switch(ev.key.keysym.sym) {
					case SDLK_p:
						if (pause) {
							pause = 0;
							log_init(LOG_FILE_NAME, "a");
						}
						else {
							pause = 1;
							log_flush();
							log_end();
						}
					default:
						break;
				}
			}
		}
		
		if( SDL_TICKS_PASSED(SDL_GetTicks(), next_frame) && !pause) {
			// draw background
			SDL_BlitSurface(bg, NULL, screen, NULL);
			
			men = Man_getList(&man_list_size);
			check(men != NULL, "Failed to update, list was NULL.");
			Man_t *tgt = NULL;
			for( i = 0; i < man_list_size; i++) {
				//debug("Checking man: %d", i);
				tgt = &(men[i]);
				check(tgt != NULL, "Target man is NULL.");
				
				if(tgt->dead != 0) 
					continue;
				
				rc = Man_update(tgt);
				/*if( rc == -1 ) {
					log_err("Man update failed - printing vitals!");
					log_err("  Man #%d: (%d, %d)", tgt->id, (int) tgt->x, (int) tgt->y);
					if(tgt->name != NULL)
						log_err("  type:%d  col:%d  name:%s", tgt->type, 
							tgt->colour, tgt->name);
					else
						log_err("  type:%d  col:%d", tgt->type, tgt->colour);
						
				}*/
				
				rc = Man_getSpriteBox(tgt, &draw_box, &draw_x, &draw_y);
				check(rc == 0, "Could not get image data from Man#%d", i);
				screen_box.x = draw_x;
				screen_box.y = draw_y;
				SDL_BlitSurface(man_sheet, &draw_box, screen, &screen_box);
				
				rc = Man_getHealthBox(tgt, &health_bar_sprite, &health_bar_screen);
				check(rc == 0, "Could not get health bar data from Man#%d", i);
				SDL_BlitSurface(man_sheet, &health_bar_sprite, screen, &health_bar_screen);
			}
			
			if( --log_frames >= 0 ) {
				log_flush();
				log_frames = LOG_FRAME_DELAY;
			}
			//debug("frame.");
			next_frame = SDL_GetTicks() + TIMER_RES;
			SDL_UpdateWindowSurface(window);
			
		}
		
	}
	
	log_info("Program closing..");
	log_flush();
	// cleanup fallthrough
error:
	log_flush();
	if(bg) SDL_FreeSurface(bg);
	if(man_sheet) SDL_FreeSurface(man_sheet);
	if(screen) SDL_FreeSurface(screen);
	if(window) SDL_DestroyWindow(window);
	SDL_Quit();
	log_info("Finished.");
	log_flush();
	log_end();
	return rc;
}


int init_window(SDL_Window **gWnd, SDL_Surface **gScreen)
{
	if(*gWnd || *gScreen) log_warn("gWnd and gScreen parameters should both be NULL - check initialisation.");
	
	int rc = SDL_Init(SDL_INIT_VIDEO);
	check(rc >= 0, "Failed to initialise SDL properly. Err#%d> %s", rc, SDL_GetError());
	
	*gWnd = SDL_CreateWindow(WINDOW_TITLE, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	check(*gWnd != NULL, "Failed to initialise SDL_Window: %s", SDL_GetError());
	
	*gScreen = SDL_GetWindowSurface(*gWnd);
	check(*gScreen != NULL, "Failed to initialise SDL_Surface as screen: %s", SDL_GetError());
	
	return 0;
	
error:
	return -1;

}



int load_image(SDL_Surface **gTarget, const char *path)
{
	bstring fp = NULL;
	char *cbuf = NULL;
	int rc = 0;

	File_GetResource_cstr(path, &fp);
	check(fp != NULL, "Could make path from cstring.");
	rc = Util_CString_Convert(fp, &cbuf);
	check(rc == 0, "Failed to convert bstring to char * string.");
	
	log_info("Loading image: %s", cbuf);
	*gTarget = SDL_LoadBMP(cbuf);
	check(*gTarget != NULL, "Could not load BMP: %s", SDL_GetError());
	
	if(cbuf) free(cbuf);
	return 0;

error:
	if(cbuf) free(cbuf);
	return -1;

}
