# code by Tom Marks 2015
# linux build added by Tom Marks 01 2024
gcc -I/usr/include -I. game.c man.c ashare/bstrlib.c ashare/share_utils.c -lSDL2 -lm -o ../bin/men.linux.x86

