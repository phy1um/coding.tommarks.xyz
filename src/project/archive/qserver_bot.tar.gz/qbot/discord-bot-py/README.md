# QBrowser Discord Bot #
A Discord bot for displaying Quake server information in compliance with my Quake Server Browser standard (link TBA)

## Tools, Environment and Code ##
This bot is written for python >= 3.6 (tested and developed in 3.6) 
Required Libraries (from pip): discord.py, requests 
All python code must comply with pep8 
