
SERVER_CHUNK_STRING = "{} **{}** ({})\n```====================\n\tmap: {}\n" +\
    "\tmode: {}\n\tplayers: {}/{}\n\tplay: /connect {}:{}" + \
    "\n====================```"
