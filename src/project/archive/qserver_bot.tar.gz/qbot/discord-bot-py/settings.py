
# api token for discord bot
DISCORD_API_TOKEN = "x"
