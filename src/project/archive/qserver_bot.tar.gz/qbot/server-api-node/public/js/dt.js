$(document).ready(function () {
    $("#browser-table").DataTable({
        paging: false,
        ordering: true,
        info: false
    });

})