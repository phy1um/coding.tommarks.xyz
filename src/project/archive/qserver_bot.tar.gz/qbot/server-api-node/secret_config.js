module.exports = {
	GEO_KEY: "ad3acca253d3b091faa8b8460f52234c",
    CACHE_WRITE_RATE: 60000
};

