
#include "world.h"
#include "ashare/dbg.h"

#include "class/fish.h"
#include "class/playershark.h"

#include <stdlib.h>

// DOCUMENTATION NOTE:
//   No info on return values for any of these functions, because it's all
//   either R_SUCCESS or R_FAIL. 

// no longer used :s
//static int pow10[] = {10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000};


/**
	World_Create()
		Params:
		 World_t *target - world context to initialise
		 int max_fish - maximum number of fish that can be alive at once
			in this room
			
	 Called to initialise a World_t struct. Sets everything up ready to run
	  actual game logic. Other than the pointer +1 weirness for working the 
	  player member into the main entity array, the only interesting thing
	  here is that we pre-initialise our entire array of Fish to objects
	  that do nothing, and set them to not render. From here you call 
	  World_SpawnFish() to actuaslly create an interactive, rendering
	  fish in the world.
*/
RETURNV World_Create(World_t *target, int max_fish)
{
	check(target != NULL, "Target  was not allocated!");
	check(max_fish > 0, "Invalid parameter for maximum fish entites.");
	
	// +1 to make room for a player!
	GameClass_t *entity_array = calloc(max_fish + 1, sizeof(GameClass_t));
	check_mem(entity_array);
	
	target->max_fish = max_fish;
	// get our +1 from this array as our player data - this is never used as an array!
	target->player = entity_array + max_fish;
	// we use THIS part as an array, but never read into the extra player
	//  slot because we stop one before when iterating (i < max_fish)
	target->fish_array = entity_array;
	
	// we'll keep an extra space here for the player too!
	target->fish_array_active = calloc(max_fish + 1, sizeof(int));
	check_mem(target->fish_array_active);
	// the extra +1 slot for the player is always active
	target->fish_array_active[max_fish] = 1;
	
	
	target->fish_array_head = 0;
	
	target->fish_count = 0;
	target->player_score = 0;
	target->ticks = 0;
	
	// we account for the player here, because this value is used
	// when iterating over ALL objects, rather than just the fish
	target->total_entity_count = max_fish + 1;
	
	int i = 0;
	int pos = 0;
	RETURNV rv = R_SUCCESS;
	// initialise the memory in this fish array, according to the
	//  actual class definition in fish.c/fish.h
	for( i = 0; i < max_fish; i++ ) {
		rv = Object_New( ((target->fish_array) + i), Fish, VLIST(&pos, "FishDead") );
		check(rv == R_SUCCESS, "Could not initialise fish array!");
	}
	
	return R_SUCCESS;
error:
	return R_FAIL;
}

/**
	World_Destroy()
		Params:
		 World_t *target - world context to cleanup
		 
	 Clean up the entire World_t struct and all associated memory.
*/
RETURNV World_Destroy(World_t *target)
{
	check(target != NULL, "Target must exist.");
	int i = 0, sv = 0;
	if(target->fish_array && target->player) {
		// destroy object data
		for( i = 0; i < target->max_fish + 1; i++ ) {
			if( target->fish_array[i].objData ) {
				free( target->fish_array[i].objData );
			}
		}
		free(target->fish_array);
		log_info("World Entity array cleaned.");
	}
	else {
		log_warn("Invalid memory in World_t struct, cannot free!");
		sv = 1;
	}
	
	if(target->fish_array_active) {
		free(target->fish_array_active);
	}
	else {
		sv = 1;
	}
	
	if(sv = 1) {
		log_err("Could not properly cleanup World_t memory.");
		return R_FAIL;
	}
	
	log_info("Finshed cleaning World_t memory.");
	return R_SUCCESS;
error:
	return R_FAIL;
}


/**
	World_SpawnPlayer()
		Params:
		 World_t *world - world context
		 int sx - x coordinate to create player
		 int sy - y coordinate to create player
		
	 We store the player specially in a special extra entity array slot. This function
	  is just housekeeping for that, to save tedious pointer fiddling. This system does
	  lock us to 1 player per world, but multiple players is beyond the scope of this project.
*/
RETURNV World_SpawnPlayer(World_t *world, int sx, int sy)
{
	check(world != NULL, "Invalid world parameter - cannot be NULL.");
	check(world->player != NULL, "Invalid world parameter - must be properly initialised.");
	return Object_New( world->player, PlayerShark, VLIST(&sx, &sy) );
error:
	return R_FAIL;
}


/**
	World_GetPlayer()
		Params:
		 World_t *world - world context
		 
	 Get the player for this world. Returns NULL on error
*/
GameClass_t *World_GetPlayer(World_t *world)
{
	check(world != NULL, "Invalid world parameter - cannot be NULL.");
	check(world->player != NULL, "Invalid world parameter - must be properly initialised.");
	return world->player;
error:
	return NULL;
}


/**
	World_SpawnFish()
		Params:
		 World_t *world - world context
		 int sy - starting y coordinate for fish (sometimes used as misc parameter)
		 const char *fish_type - string name of type to spawn
		  (we use string to facilitate easier dynamic loading of data at runtime, in the future)
		  
		 Creates a new Fish object (GameClass_t) in the world context, if there is room in 
		  the fish array. The fist object already exists, but is reinitialised with new data
		  by calling Fish_Remake().
	 
*/
RETURNV World_SpawnFish(World_t *world, int sy, const char *fish_type)
{
	check(world != NULL, "Invalid world parameter - cannot be NULL.");
	check(fish_type != NULL, "Invalid fish type name - cannot be NULL.");
	check(world->fish_array != NULL && world->fish_array_active != NULL,
		"World data not properly initialised.");
	
	check(world->fish_count < world->max_fish, "No room for new fish: %d/%d!", world->fish_count, world->max_fish);
	
	// get the active value (0 or 1) of the next fish in the array
	int fi = world->fish_array_active[world->fish_array_head];
	// we need a counter, because fish_array_head can loop back to 0
	int incr = 0;
	// while the fish isn't inactive (0), iterate through the array
	while( fi != 0 ) {
		world->fish_array_head++;
		if(world->fish_array_head >= world->max_fish) {
			world->fish_array_head = 0;
		}
		fi = world->fish_array_active[world->fish_array_head];
		incr++;
		// if our counter is > world->max_fish then there is no room left!
		check(incr <= world->max_fish, "No room for new fish!");
	}
	
	// get the address of the first inactive fish, and remake it
	GameClass_t *fish_target = &(world->fish_array[world->fish_array_head]);
	RETURNV rv = Fish_Remake(fish_target, world, world->fish_array_head, sy, fish_type);
	check(rv == R_SUCCESS, "Failed to reinitialise Fish in World.");
	// incrememnt our fish counter otherwise everything breaks!
	world->fish_count++;
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


/**
	World_GetEntityList()
		Params:
		 World_t *world - 
		 (OUT) GameClass_t **list_pointer - array-pointer passed by reference, to take the value
			of the world's GameClass_t array
		 (OUT) int **active_flags - as above for the int array of active flags
		 (OUT) int *entity_count - value to be written out containing the size of the above arrays
		 
		 Used to expose the values of various World_t arrays in a simple way. As it stands this
		  function serves little purpose, but if this behavior becomes more complex in the future
		  it will save a lot of code reshuffling. If the final version of the function is this
		  simple it may be removed from the main() loop in favor of directly reading these
		  struct values!
*/
RETURNV World_GetEntityList(World_t *world, GameClass_t **list_pointer, int **active_flags,
	int *entity_count)
{
	check(world != NULL, "Invalid world parameter - cannot be NULL.");
	check(world->fish_array != NULL && world->fish_array_active != NULL,
		"World data not properly initialised.");
	check(world->player != NULL, "Player is not initialised properly.");
	check(entity_count != NULL, "This is strange!");
	
	*list_pointer = world->fish_array;
	*active_flags = world->fish_array_active;
	*entity_count = world->total_entity_count;
	//*entity_count = 5;
	//int t = world->total_entity_count;
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


/**
	World_BeginFrame()
	
	 Should be the first thing called in every new game frame. Check score values are 
	  in-bounds, and call the housekeeping function for clearing player collisions.
*/
RETURNV World_BeginFrame(World_t *target)
{
	if(target->player_score > 999999)
		target->player_score = 999999;
	else if(target->player_score < 0)
		target->player_score = 0;
		
	RETURNV rv = Player_ClearCollisions();
	
error: // fallthrough
	return rv;
}


/**
	World_GetScoreAsArray()
		Params:
		 int num - number to array-ify
		 int *array_out - array of AT LEAST size max_digits to write values to
		 int max_digits - most digits we care about reading
		 
		A fun utility function to break a number down into an array of integers, ie:
		 123,456 would become (1, 2, 3, 4, 5, 6).
*/
RETURNV World_GetScoreAsArray(int num, int *array_out, int max_digits)
/* Attempt 1 was a bit messy :s
{
	check(array_out != NULL && max_digits >= 1, "Invalid input!");
	int it = 0, cut = 0, i = 0, j = 0;
	do {
		cut = (num / pow10[it])*pow10[it];
		cut = num - cut;
		for(i = it; i > 0; i--) {
			cut -= array_out[i - 1];
		}
		if(it > 0) {
			array_out[it] = cut/pow10[it - 1];
		}
		else {
			array_out[it] = cut;
		}
		
		check(array_out[it] >= 0 && array_out[it] <= 9, 
				"Invalid value %d written to array! Score: %d, Iteration: %d", array_out[it], num, it);
		it++;
	} while(it < max_digits);
	
	return R_SUCCESS;
error:
	return R_FAIL;
}*/
{
	check(array_out != NULL && max_digits >= 1, "Invalid input!");
	int i;
	for(i = 0; i < max_digits; i++) {
		// this is a cool method for breaking numbers down like this, and works in multiple bases!
		array_out[i] = num % 10;
		num /= 10;
	}
	return R_SUCCESS;
error:
	return R_FAIL;
}
