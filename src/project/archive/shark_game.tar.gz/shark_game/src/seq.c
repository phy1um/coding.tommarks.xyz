
#include "seq.h"
#include "world.h"


#define PHASE_DATA_SIZE 20

struct seq_phase_s {
	RETURNV (*hTick_f)(Seq_Phase*, World_t*);
	RETURNV (*hEnd_cb)(Wave_t*);
	Wave_t parent;
	int lifetime;
	int difficulty;
	int prize_count;
	int health_count;
	int rng[8];
};



static Seq_PhaseData phase_data_array[PHASE_DATA_SIZE] = {0};
static int phase_data_head;
static int phase_data_load_safe;


RETURNV Seq_PhaseInit(void)
{
	check(phase_data_array != NULL, "Error initialising program memory.");
	check(phase_data_load_safe == 0, 
		"Bad loading state for phase data, make sure this function is only called once!");
	phase_data_head = 0;
	phase_data_load_safe = 1;
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Seq_PhaseLoad(int(*init_fn)(Seq_Phase*, Seq_PhaseData*, Wave_t*), 
	int(*tick_fn)(Seq_Phase*, World_t*))
{
	check(init_fn != NULL && tick_fn != NULL, "Invalid functions passed to phase loading.");
	check(phase_data_load_safe == 1, 
		"Invalid loading state for phase data - make sure Seq_PhaseInit() was called first!");
	check(phase_data_head < PHASE_DATA_SIZE, "No room for new phase data");
	
	phase_data_array[phase_data_head].hInit_f = init_fn;
	phase_data_array[phase_data_head].hTick_f = tick_fn;
	phase_data_head++;
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Seq_PhaseLoad_Done(void)
{
	check(phase_data_load_safe == 1, "Invalid loading state, must call Seq_PhaseInit() first!");
	check(phase_data_head <= 0, "No phases loaded, or error in moving phase loader head.");
	
	phase_data_load_safe = 0;
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Wave_Create(Wave_t *target, int difficulty_modifier, int phase_count)
{
	check(target != NULL, "Invalid target, memory not initialised.");
	check(difficulty_modifier >= 0 && phase_count > 0, "Invalid parameters.");
	check(target->load_flag != LOAD_DONE, "Wave alread has data loaded - call Wave_Destroy() first!");
	
	target->phase_count = phase_count;
	target->phase_head = 0;
	target->phase_array = malloc(phase_count * sizeof(Seq_Phase));
	target->difficulty_modifier = difficulty_modifier;
	target->health_given = 0;
	target->wave_flags = 0;
	
	target->load_flag = LOAD_LOADING;
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Wave_LoadPart(Wave_t *target)
{

	RETURNV rv = R_FAIL;
	
	check(target != NULL && target->phase_array != NULL, "Invalid target memory.");
	check(target->load_flag == LOAD_LOADING, "Invalid loading state - make sure this is done in order!");
	check(target->phase_head >= 0, "Bad wave data - something has gone wrong internally.");
	#ifdef CF_CHECK_STRICT
	check(phase_data_array != NULL, "Bad phase array memory.");
	check(phase_data_load_safe == 0, "Um.");
	#endif
	
	if(target->phase_head >= target->phase_count) {
		target->load_flag = LOAD_DONE;
		return R_SUCCESS;
	}
	
	else {
		
		int phase_id = Util_Random(phase_data_head);
		#ifdef CF_CHECK_STRICT
		check(phase_id >= 0 && phase_id < phase_data_head, "Random generator error!");
		#endif
		Seq_PhaseData *data = phase_data_array + phase_id;
		rv = data->hInit_f( (target->phase_array + target->phase_head), (phase_data_array + phase_id), target );
		check(rv == R_SUCCESS, "Failed to initialise Phase data from initialisation function!");
		return R_SUCCESS;
	}
	
error:
	return rv;
}


WAVEFLAGS Wave_Update(Wave_t *target, World_t *world)
{
	check(target != NULL && target->phase_array, "Invalid target memory.");
	
	if(
	#ifdef CF_CHECK_STRICT
		target->phase_head >= 0 && (target->phase_head < target->phase_count)
	#else
		target->phase_head < target->phase_count
	#endif
	) {
		(target->phase_array + target->phase_head)->hTick_f(target->phase_array + target->phase_head, world);
	}
	return target->wave_flags;
	
error:
	target->wave_flags = WAVE_ERR;
	return WAVE_ERR;
}


RETURNV Wave_PhaseEnd(Wave_t *wave)
{
	check(wave != NULL, "No wave data here to work on.");
	#ifdef CF_CHECK_STRICT
	check(wave->phase_array != NULL, "Phase array has been freeded or corrupted somehow!");
	check(wave->phase_head >= 0 && wave->phase_head <= wave->phase_count, "Invalid phase head value.");
	#endif
	
	check(Wave_Flags(wave, WAVE_ERR), "Wave is in an error state.");
	
	if(wave->phase_head <= wave->phase_count) {
		wave->phase_head++;
	}
	else {
		wave->wave_flags |= WAVE_DONE;
	}
	
	
	return R_SUCCESS;
error:
	wave->wave_flags |= WAVE_ERR;
	return R_FAIL;
}


RETURNV Wave_Destroy(Wave_t *target)
{
	check(target != NULL, "Target has already been freed.");
	if(target->phase_array) free(target->phase_array);
	if(target) free(target);
	
	return R_SUCCESS;
error:
	return R_FAIL;
}
