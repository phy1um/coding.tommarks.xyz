#ifndef SHARE__UTILS__H__PHY
#define SHARE__UTILS__H__PHY

#include "dbg.h"
#include "bstrlib.h"

extern const_bstring RESOURCE_PATH;

bstring File_GetResource_cstr(const char *sub_directory, bstring *out);
bstring File_GetResource(bstring sub_directory, bstring *out);
int Util_CString_Convert(bstring in, char **out);

int Util_Random(int max);
int Util_SeedRandom(void);

#endif