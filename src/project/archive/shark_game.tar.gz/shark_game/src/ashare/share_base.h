#ifdef _WIN32

#undef __func__
#define __func__ __FUNCTION__

#endif