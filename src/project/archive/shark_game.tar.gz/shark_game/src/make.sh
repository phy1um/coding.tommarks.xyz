# code by Tom Marks 2016
# linux build added by Tom Marks 01 2024
SOURCES="./game.c ./world.c ./image.c ./ashare/bstrlib.c ./ashare/share_utils.c ./object.c"
CLASSES="./class/playershark.c ./class/fish.c"
gcc -I/usr/include -I. $SOURCES $CLASSES -lSDL2 -lm -o ../bin/shark.linux.x86

