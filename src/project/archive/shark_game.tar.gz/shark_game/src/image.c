#define PH_SRC__IMAGE_C__

#include "global_def.h"
#include "image.h"

#include "ashare/share_utils.h"
#include "ashare/share_base.h"
#include "ashare/dbg.h"

#include <SDL2/SDL.h>
#include <stdarg.h>
#include <stdlib.h>

static SDL_Surface **sprite_sheet_array = NULL;
static char **sprite_sheet_names = NULL;
static int sprite_sheet_max = 0;
static int sprite_sheet_count = 0;

static SpriteData_t **animations = NULL;
static int animation_count = 0;
static int animation_max = 0;
static char **animation_names = NULL;

static SpriteData_t *sprites = NULL;
static int sprites_count = 0;
static int sprites_max = 0;
static char **sprites_names = NULL;


#ifdef _WIN32
static ImageResource_t Image_search_array_for(char **arr, int size, const char *str)
#else
static inline ImageResource_t Image_search_array_for(char **arr, int size, const char *str)
#endif
{
	int i;
	char *tstr;
	for( i = 0, tstr = arr[i]; i < size; i++, tstr = arr[i] ){
		//debug("Iter %d: %c", i, tstr[0]);
		//debug_flush();
		if( strcmp(tstr, str) == 0 ) {
			debug("Matched strings %s and %s", tstr, str);
			return i;
		}
	}
	
	debug("Returning NULL");
	//debug_flush();
	return HANDLE_NULL;
}


IMAGE_HANDLE Image_Get_SpriteSheet_Handle(const char *str)
{
	return Image_search_array_for(sprite_sheet_names, sprite_sheet_count, str);
}

IMAGE_HANDLE Image_Get_Sprite_Handle(const char *str)
{
	return Image_search_array_for(sprites_names, sprites_count, str);
}

IMAGE_HANDLE Image_Get_Animation_Handle(const char *str)
{
	return Image_search_array_for(animation_names, animation_count, str);
}


RETURNV Image_Init(int ssheet_max, int spr_max, int anims_max)
{
	sprite_sheet_max = ssheet_max;
	sprites_max = spr_max;
	animation_max = anims_max;
	
	sprite_sheet_array = malloc(ssheet_max * sizeof(SDL_Surface *));
	sprite_sheet_names = malloc(ssheet_max * sizeof(char*));
	
	sprites = malloc(spr_max * sizeof(SpriteData_t));
	sprites_names = malloc(spr_max * sizeof(char*));
	
	animations = malloc(anims_max * sizeof(SpriteData_t *));
	animation_names = malloc(anims_max * sizeof(char*));
	
	check_mem(sprite_sheet_array);
	check_mem(sprite_sheet_names);
	check_mem(sprites);
	check_mem(sprites_names);
	check_mem(animations);
	check_mem(animation_names);
	
	return R_SUCCESS;
error:
	return R_FAIL;
}



RETURNV Image_AddAnimation(const char *name, int frames_count, ...)
{
	check(animations != NULL && animation_names != NULL, 
		"Animation memory not initialised. Make sure Image_Init(...) is called!");
	check(animation_count < animation_max, "Not enough space in buffer for new Animation!");
	animations[animation_count] = malloc( frames_count * sizeof(SpriteData_t) );
	check_mem( animations[animation_count] );
	
	va_list ap;
	va_start(ap, frames_count);
	int i;
	SpriteData_t *read;
	SpriteData_t *prev_alloc = NULL;
	for( i = 0; i < frames_count; i++ ) {
		read = va_arg(ap, SpriteData_t*);
		check(read != NULL, "Unexpected end of vararg list reached.");
		memcpy( (animations[animation_count] + i), read, sizeof(SpriteData_t) );
		
		if( i > 0 ) {
			// setup the next pointer to go to the following frame
			(animations[animation_count] + i - 1)->next = read;
		}
	}
	va_end(ap);
	
	// loop from front to back
	(animations[animation_count] + i)->next = animations[animation_count];
	
	animation_names[animation_count] = malloc( strlen(name) * sizeof(char) );
	strcpy( animation_names[animation_count], name );
	animation_count++;
	
	log_info("Loaded Animation: %s", name);
	return R_SUCCESS;

error:
	if( animations[animation_count] ) {
		free(animations[animation_count]);
	}
	
	if( animation_names[animation_count] ) {
		free( animation_names[animation_count] );
	}
	
	log_err("Failed to load animation: %s", name);
	return R_FAIL;
}


RETURNV Image_AddSprite(const char *name, IMAGE_HANDLE sprite_sheet, int image_x, int image_y,
	int image_w, int image_h)
{
	check(sprites != NULL && sprites_names != NULL,
		"Sprite memory not initialised. Make sure Image_Init(...) is called.");
	check(sprites_count < sprites_max, "Not enough space in buffer for new Sprite!");
	
	SpriteData_t *sp = &(sprites[sprites_count]);

	sp->image.x = image_x;
	sp->image.y = image_y;
	sp->image.w = image_w;
	sp->image.h = image_h;
	sp->sprite_sheet = Image_Get_SpriteSheet(NULL, sprite_sheet);
	sp->next = NULL;
	sp->anim_time = ANIM_NONE;
	
	sprites_names[sprites_count] = malloc( strlen(name) );
	strcpy( sprites_names[sprites_count], name );
	
	sprites_count++;
	
	log_info("Loaded Sprite: %s", name);
	return R_SUCCESS;

error:

	if( sprites_names[sprites_count] )
		free(sprites_names[sprites_count]);
		
	log_err("Failed to load sprite: %s", name);
	return R_FAIL;
}


RETURNV Image_LoadSpriteSheet(const char *path, const char *name, int alpha_on, int alpha_r,
	int alpha_g, int alpha_b)
{

	bstring fp = NULL;
	char *cbuf = NULL;
	RETURNV rv = R_SUCCESS;
	
	check( sprite_sheet_array != NULL && sprite_sheet_names != NULL,
		"Sprite Sheet memory not initialised. Make sure Image_Init(...) is called.");
	check( sprite_sheet_count < sprite_sheet_max, "No space in buffer for new Sprite Sheet!");
	
	File_GetResource_cstr(path, &fp);
	check(fp != NULL, "Failed to get resource path as bstring.");
	rv = Util_CString_Convert(fp, &cbuf);
	check(rv == R_SUCCESS, "Failed to convert resource path to c-string.");
	
	sprite_sheet_array[sprite_sheet_count] = SDL_LoadBMP(cbuf);
	check( sprite_sheet_array[sprite_sheet_count] != NULL, 
		"Failed to create SDL_Surface: %s", SDL_GetError());
	
	if( alpha_on > 0 ) {
		SDL_PixelFormat *fmt = sprite_sheet_array[sprite_sheet_count]->format;
		Uint32 alpha_col = SDL_MapRGB(fmt, alpha_r, alpha_g, alpha_b);
		SDL_SetColorKey(sprite_sheet_array[sprite_sheet_count], SDL_TRUE, alpha_col);
	}
	
	sprite_sheet_names[sprite_sheet_count] = malloc(strlen(name) * sizeof(char));
	strcpy(sprite_sheet_names[sprite_sheet_count], name);
	
	if(cbuf)free(cbuf);
	sprite_sheet_count++;
	log_info("Loaded Sprite Sheet: %s", name);
	return R_SUCCESS;

error:
	if(cbuf) free(cbuf);
	log_err("Failed to load Sprite Sheet: %s", name);
	return R_FAIL;
}


RETURNV Image_SetSprite(Sprite_t *sp, SpriteData_t *data)
{
	check(sp != NULL && data != NULL, "Bad parameters - NULL passed to function.");
	sp->sprite_sheet = data->sprite_sheet;
	sp->current_frame = data;
	memcpy(&(sp->image_position), &(data->image), sizeof(SDL_Rect));
	return R_SUCCESS;
error:
	return R_FAIL;
}


SpriteData_t *Image_Get_Sprite(const char *str, SPRITE_HANDLE id)
{
	if( str != NULL ) {
		id = Image_Get_Sprite_Handle(str);
	}
	
	HANDLE_VALIDATE(id);
	check(id < sprites_count, "Sprite handle was too large.");
	return (sprites + id);
	
error:
	if( str != NULL ){
		log_err("Could not get sprite: %s", str);
	}
	return NULL;
}


SpriteData_t *Image_Get_Animation(const char *str, ANIM_HANDLE id)
{
	if( str != NULL ) {
		id = Image_Get_Animation_Handle(str);
	}
	
	HANDLE_VALIDATE(id);
	check(id < animation_count, "Animation handle was too large.");
	return animations[id];
	
error:
	if( str !=NULL ) {
		log_err("Could not get animation: %s", str);
	}
	return NULL;
}


SDL_Surface *Image_Get_SpriteSheet(const char *str, IMAGE_HANDLE id)
{
	if( str != NULL ) {
		id = Image_Get_SpriteSheet_Handle(str);
	}
	
	HANDLE_VALIDATE(id);
	check(id < sprite_sheet_count, "Sprite Sheet handle was too large.");
	return (sprite_sheet_array[id]);
	
error:
	if( str !=NULL ) {
		log_err("Could not get sprite sheet: %s", str);
	}
	return NULL;
}


RETURNV Image_FreeAll(void)
{
	int i;
	if(sprite_sheet_array) {
		for( i = 0; i < sprite_sheet_count; i++ ) {
			if(sprite_sheet_array[i]) SDL_FreeSurface(sprite_sheet_array[i]);
		}
		free(sprite_sheet_array);
	}
	
	if(animations) {
		for( i = 0; i < animation_count; i++ ) {
			if(animations[i]) free(animations[i]);
		}
		free(animations);
	}
	
	if(sprites) free(sprites);
	
	if(sprite_sheet_names) {
		for( i = 0; i < sprite_sheet_count; i++ ) {
			if(sprite_sheet_names[i]) free(sprite_sheet_names[i]);
		}
		free(sprite_sheet_names);
	}
	
	if(animation_names) {
		for( i = 0; i < animation_count; i++ ) {
			if(animation_names[i]) free(animation_names[i]);
		}
		free(animation_names);
	}
	
	if(sprites_names) {
		for( i = 0; i < sprites_count; i++ ) {
			if(sprites_names[i]) free(sprites_names[i]);
		}
		free(sprites_names);
	}
	
	log_info("All image memory cleaned.");
	return R_SUCCESS;
}
