#ifndef SHARK_SRC__OBJECT_H__
#define SHARK_SRC__OBJECT_H__

#include <stdarg.h>
#include <stdint.h>

#include "ashare/dbg.h"
#include "global_def.h"

/** !!!WARNING!!!
	This is a messy header and seriously lacking in documentation for the time being.
	Really sorry about this.
	
	Really.
	
	:(
*/

// maximum number of classes that can be defined
#define CLASS_MAX 1000

typedef int OBJDEF_TYPE;
#define CLASS_ID_ERR -1

typedef uint32_t OBJDEF_ID;
typedef uint32_t Object;

typedef void* OBJECT_DATA;
typedef RETURNV (*class_load_fn)(void);

typedef struct GameClass_s GameClass_t;

struct GameClass_s {
	OBJECT_DATA objData;
	OBJDEF_TYPE type;
	OBJDEF_ID id;
	EntityData_t edata;
	
	RETURNV (*hUpdate_f)(GameClass_t*, World_t*);
	RETURNV (*hAnim_f) (GameClass_t*);
	RETURNV (*hInit_f) (GameClass_t*, va_list);
	RETURNV (*hLogDump_f) (GameClass_t*);
	RETURNV (*hMemoryFree_f) (GameClass_t *self);
	CollisionType (*hCollides_f) (GameClass_t *self, float x, float y);
	
	size_t data_size;
};

//called in main
RETURNV Object_Begin(void);
RETURNV Object_LoadClasses(void);
RETURNV Object_CleanAll(void);

// memory
GameClass_t *Object_Alloc(int count);
RETURNV Object_Free(GameClass_t *target);

// class housekeeping, can't be static because other classes need them
OBJDEF_TYPE Object_AssignClassID(const char *class_name);
OBJDEF_ID Object_GetUID();
RETURNV Object_PushLoadForClass(class_load_fn func);

// utility for naming classes, helps make logfiles better
const char *Object_GetClassString(OBJDEF_TYPE class_type);

RETURNV Object_Create(GameClass_t *target, GameClass_t proto, ...);
#define Object_New(tgt, class, ...) Object_Create(tgt, Class_proto##class, __VA_ARGS__)

#define object_init(obj, ...) obj->hInit_f(obj, __VA_ARGS__)
#define object_update(obj, w) obj->hUpdate_f(obj, w)
#define object_anim(obj) obj->hAnim_f(obj)
#define object_log(obj) obj->hLogDump_f(obj)

// use in C body to create class implementation
#define CLASS_DEFINE(name) GameClass_t Class_proto##name; RETURNV Class_Load##name(void)
#define CLASS_UPDATE(name, fn) Class_proto##name.hUpdate_f = &fn
#define CLASS_ANIM(name, fn) Class_proto##name.hAnim_f = &fn
#define CLASS_INIT(name, fn) Class_proto##name.hInit_f = &fn
#define CLASS_LOG(name, fn) Class_proto##name.hLogDump_f = &fn
#define CLASS_COLLISION(name, fn) Class_proto##name.hCollides_f = &fn
#define CLASS_CHECKID(name) check(Class_proto##name.type != CLASS_ID_ERR, "Invalid class ID assigned to: " #name)
#define CLASS_FREE(name, fn) Class_proto##name.hMemoryFree_f = &fn
#define CLASS_END(name) Class_proto##name.objData = NULL; log_info("@@Loaded class: " #name); return R_SUCCESS; error: return R_FAIL

#define CLASS_GEN_TYPEID(name) Class_proto##name.type = Object_AssignClassID(#name)

#define CLASS_SETLOAD(name) Object_PushLoadForClass(&Class_Load##name)

// use in header to make class usable in other files
#define CLASS_EXPORT(name) extern GameClass_t Class_proto##name; RETURNV Class_Load##name(void)


#define Object_Setup(tgt, other) tgt->hInit_f = other.hInit_f; tgt->hAnim_f = other.hAnim_f; tgt->hUpdate_f = other.hUpdate_f; tgt->hLogDump_f = other.hLogDump_f; tgt->type = other.type; tgt->hCollides_f = other.hCollides_f

#define check_param(p, c, s) check( (p) != NULL, "Invalid parameters to "#c" initialisation. Param: "#s );

/*

  example class implementation for a *.c file

CLASS_DEFINE(ClassName) {
	CLASS_UPDATE(ClassName, &update_fn);
	CLASS_ANIM(ClassName, &anim_fn);
	CLASS_INIT(ClassName, &init_fn);
	CLASS_LOG(ClassName, &log_fn);
	CLASS_GEN_TYPEID(ClassName);
	CLASS_END(ClassName);
} 

  them have in the header:
CLASS_EXPORT(ClassName)


*/


#endif
