#ifndef PH_SRC__GLOBAL_DEF_H__
#define PH_SRC__GLOBAL_DEF_H__

#include <SDL2/SDL.h>

#define RETURNV int
#define R_SUCCESS 0
#define R_FAIL -1
#define R_FATAL -2

// used for passing variadic arguments to object initialisers. just a 
//  safety measure to ensure we don't over-scan into undefined stack memory
#define VLIST(...) __VA_ARGS__, NULL


#ifdef CF_CHECK_STRICT
#define CF_CHECK_SOME
#endif

// get string from RETURNV value - might get reworked to be
//  nicer later, but probably not
#define RV_STRING(rv) ( rv < 0 ? "ERROR" : "SUCCESS" )


#define CollisionType int
#define COLLISION_NULL 0
#define COLLISION_PLAYER 1
#define COLLISION_FISH 2
#define COLLISION_DEATH 3
#define COLLISION_HARM 4
#define COLLISION_POISON 5
#define COLLISION_MAX 6

#define collision_string(e) collision_names[(e)]
#define check_collision_valid(e) check( (e) >= COLLISION_NULL && (e) < COLLISION_MAX, "Invalid collision value.")
extern char *collision_names[COLLISION_MAX];

// do these first because thse stucts may or may not contain
//  other struct types referenced by their typedef name
typedef struct entity_data_s EntityData_t;
typedef struct world_data_s World_t;
typedef struct sprite_data_s SpriteData_t;
typedef struct sprite_s Sprite_t;
typedef int ImageResource_t;


// represents an instance of an image, and is owned by an entity to be
//  drawn to the screen
struct sprite_s {
	SDL_Rect world_position;
	SDL_Rect image_position;
	SDL_Surface *sprite_sheet;
	int in_animation;
	int frame_counter;
	SpriteData_t *current_frame;
};

// contains all of the information a Sprite_t needs to be created,
//  and isn't owned by an entity.
struct sprite_data_s {
	SDL_Rect image;
	SDL_Surface *sprite_sheet;
	SpriteData_t *next;
	int anim_time;
};

// extra entity information that every object has, but isn't bound
//  to the object system
struct entity_data_s {
	SDL_Rect pos;
	int sprite_offset_x;
	int sprite_offset_y;
	int is_dead;
	CollisionType collision;
	Sprite_t image;
};


#endif
