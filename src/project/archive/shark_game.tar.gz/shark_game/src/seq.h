#ifndef PHY_SRC__SEQ_H__
#define PHY_SRC__SEQ_H__

#include "global_def.h"
#include "world.h"

#define WAVEFLAGS int
typedef struct seq_phase_s Seq_Phase;
typedef struct seq_wave_s Wave_t;

struct Seq_PhaseData_s {
	RETURNV (*hTick_f)(Seq_Phase*, World_t*);
	RETURNV (*hInit_f)(Seq_Phase*, struct Seq_PhaseData_s*, Wave_t*);
	
};

typedef struct Seq_PhaseData_s Seq_PhaseData;

#define WAVE_OK 1
#define WAVE_ERR 2
#define WAVE_DONE 4

#define LOAD_NONE 0
#define LOAD_LOADING 1
#define LOAD_DONE 2

struct seq_wave_s {
	int difficulty_modifier;
	int health_given;
	Seq_Phase *phase_array;
	int phase_count;
	int phase_head;
	WAVEFLAGS wave_flags;
	
	int load_flag;
};

RETURNV Seq_PhaseInit(void);
RETURNV Seq_PhaseLoad(int(*init_fn)(Seq_Phase*, Seq_PhaseData*, Wave_t*), int(*tick_fn)(Seq_Phase*, World_t*));
RETURNV Seq_PhaseLoad_Done(void);

RETURNV Wave_Create(Wave_t *target, int difficulty_modifier, int phase_count);
RETURNV Wave_LoadPart(Wave_t *target);

RETURNV Wave_Destroy(Wave_t *target);

WAVEFLAGS Wave_Update(Wave_t *target, World_t *world);
#define Wave_Flags(tgt, flag) ((tgt)->wave_flags & flag)
#define Wave_GetPhase(tgt) ((tgt)->phase_array + (tgt)->phase_head)

RETURNV Wave_PhaseEnd(Wave_t *wave);

#define Phase_SetEndCallback(phase) (phase)->hEnd_cb = &Wave_PhaseEnd

#endif
