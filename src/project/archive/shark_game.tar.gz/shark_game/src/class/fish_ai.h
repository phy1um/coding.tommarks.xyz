#include <math.h>
#include "fish.h" 
#include "../object.h" 
#include "../world.h" 
#include "../ashare/dbg.h" 
#include "../ashare/share_utils.h" 
#include "../ashare/share_base.h" 
#include "../global_def.h" 

#define SINE_CONST 127.32395
#define UPDATE_END() Class_protoFish.hUpdate_f(fish, world)

#define entity_data(o, f) o->edata.f
#define obj_data(o, f) ((Fish_t*)o->objData)->f

#define kill_if_off_left() if(fish->edata.pos.x < 0 - fish->edata.pos.w) {fish->edata.is_dead = 1;}
#define kill_if_off_right() if(fish->edata.pos.x > WORLD_WIDTH) {fish->edata.is_dead = 1;}
#define kill_if_off_top() if(fish->edata.pos.y < 0 - fish->edata.pos.h) {fish->edata.is_dead = 1;}
#define kill_if_off_bottom() if(fish->edata.pos.y > WORLD_HEIGHT) {fish->edata.is_dead = 1;}

static RETURNV fish_ai_horiz(GameClass_t *fish, World_t *world)
{
	
	entity_data(fish, pos.x) -= obj_data(fish, speed);

	kill_if_off_left();
	return UPDATE_END();
}

static RETURNV fish_ai_sine(GameClass_t *fish, World_t *world)
{
	
	entity_data(fish, pos.x) -= obj_data(fish, speed);
	float dy = obj_data(fish, speed2) * ((float) sin( obj_data(fish, lifetime) * 1/obj_data(fish, speed) ));
	entity_data(fish, pos.y) += dy;

	kill_if_off_left();
	return UPDATE_END();
}


static RETURNV fish_ai_sword(GameClass_t *fish, World_t *world)
{

	if(obj_data(fish, lifetime) == 0) {
		entity_data(fish, pos.x) = 0 - entity_data(fish, pos.w);
	}
	
	else if(obj_data(fish, lifetime) <= obj_data(fish, speed2)) {
		if(entity_data(fish, pos.x) + entity_data(fish, pos.w) <= 20) {
			entity_data(fish, pos.x)++;
		}
	}
	
	else {
		entity_data(fish, pos.x) += obj_data(fish, speed);
	}
	
	
	kill_if_off_right();
	return UPDATE_END();
}


static RETURNV fish_ai_crab(GameClass_t *fish, World_t *world)
{

	if(obj_data(fish, lifetime) == 0) {
		entity_data(fish, pos.x) = entity_data(fish, pos.y);
		entity_data(fish, pos.y) = 0 -entity_data(fish, pos.h);
	}
	else {
		entity_data(fish, pos.y) += obj_data(fish, speed);
	}
	//debug("Falling... %f, %f", entity_data(fish, pos.x), entity_data(fish, pos.y));
//	kill_if_off_left();
//	kill_if_off_right();
	kill_if_off_bottom();
	return UPDATE_END();
}


static RETURNV fish_ai_null(GameClass_t *fish, World_t *world)
{
	debug("Bad fish! ID: %d", obj_data(fish, fid));
	return R_FAIL;
}