
#include "tester.h"
#include "../object.h"
#include "../ashare/dbg.h"
#include "../global_def.h"

#include <stdarg.h>
#include <stdlib.h>

RETURNV Tester_Update(GameClass_t *self, World_t *world)
{
	log_info("Updating...");
	return R_SUCCESS;
}

RETURNV Tester_Anim(GameClass_t *self)
{
	return R_SUCCESS;
}

RETURNV Tester_LogDump(GameClass_t *self)
{
	return R_SUCCESS;
}

RETURNV Tester_Init(GameClass_t *self, va_list args)
{
	debug("Init object ID:%u", self->id);
	debug_flush();
	int tmp[100];
	int i=0, *scan = NULL;
	for( i = 0, scan = va_arg(args, int*); scan != NULL; 
		scan = va_arg(args, int*), i++ ) {
		tmp[i] = *scan;
	}
	debug("va_list read..");
	debug_flush();
	// i is the number of elements
	self->objData = calloc(i, sizeof(int));
	log_info("Object list size: %d", i);
	debug_flush();
	int *ilist = self->objData;
	int size = i;
	for( i = 0 ; i < size ; ilist[i] = tmp[i], i++ ) {
		debug("  #%d = %d", i, tmp[i]);
		debug_flush();
	}
	debug("Loop done.");
	debug_flush();
	
	return R_SUCCESS;
}


RETURNV Tester_EntityData(GameClass_t *self, EntityData_t **out)
{
	return R_SUCCESS;
}

RETURNV Tester_MemoryFree(GameClass_t *self)
{
	if(self->data) {
		free(data);
		return R_SUCCESS;
	}
	else {
		return R_FAIL;
	}
}


CLASS_DEFINE(Tester) {
	CLASS_UPDATE(Tester, Tester_Update);
	CLASS_ANIM(Tester, Tester_Anim);
	CLASS_INIT(Tester, Tester_Init);
	CLASS_LOG(Tester, Tester_LogDump);
	CLASS_GETDATA(Tester, Tester_EntityData);
	CLASS_FREE(Tester, Tester_MemoryFree);
	CLASS_GEN_TYPEID(Tester);
	CLASS_CHECKID(Tester);
	CLASS_END(Tester);
}
