#ifndef PH_SRC__CLASS_TESTER_H__
#define PH_SRC__CLASS_TESTER_H__

CLASS_EXPORT(Tester);

#endif