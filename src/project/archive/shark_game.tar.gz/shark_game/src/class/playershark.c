#include "playershark.h" 
#include "../object.h" 
#include "../world.h" 
#include "../ashare/dbg.h" 
#include "../ashare/share_utils.h" 
#include "../ashare/share_base.h" 
#include "../global_def.h" 
#include "fish.h"

#include <SDL2/SDL.h>
#include <stdarg.h> 
#include <stdlib.h> 

#define entity_data(o, f) o->edata.f
#define obj_data(o, f) ((PlayerShark_t*)o->objData)->f


#define MAX_FRAME_COLLISIONS 100
static int input_size;
static int *input;
static GameClass_t *frame_collisions[MAX_FRAME_COLLISIONS] = {NULL};
static int frame_collision_head;

// movement speed horizontal and vertical
#define SPEED_VERT 3
#define SPEED_HORZ 3.4
// min no. frames between bites
#define BITE_TIME_RESET 9
// maximum hold time for a bite
#define BITE_MAX_HOLD 48

// shark mouth offset, basically
// these are the points we check collision against
#define BITE_OFFSET_X 95
#define BITE_OFFSET_Y 13

// hitbox size, and sprite offset data
#define PLAYER_HITBOX_WIDTH 92
#define PLAYER_HITBOX_HEIGHT 18
#define PLAYER_SPRITE_OFFSET_X -11
#define PLAYER_SPRITE_OFFSET_Y -11


static const int PLAYER_X_MIN = 5-PLAYER_HITBOX_WIDTH;
static const int PLAYER_X_MAX = WORLD_WIDTH-PLAYER_HITBOX_WIDTH+12;
static const int PLAYER_Y_MIN = PLAYER_HITBOX_HEIGHT/-2;
static const int PLAYER_Y_MAX = WORLD_HEIGHT-(PLAYER_HITBOX_HEIGHT/2);

// no. frames between getting hit
#define HIT_BUFFER_RESET 37

// health
#define HP_START 3
#define HP_MAX 3

RETURNV PlayerCommand(PLAYERCOMMAND c, int value)
{
	int index = (int) c;
	if(index >= 0 && index < input_size) {
		input[index] = value;
		return R_SUCCESS;
	}
	
	else {
		return R_FAIL;
	}
	
}


RETURNV Player_InputInit(void)
{
	PLAYERCOMMAND max_cmd = COMMAND_SIZE;
	input_size = (int) max_cmd;
	input = calloc(input_size, sizeof(int));
	check_mem(input);
	frame_collision_head = 0;
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Player_CheckCollision(GameClass_t *object, World_t *context)
{
	check(object != NULL && context != NULL, "Bad parameters - NULL passed!");
	check(frame_collision_head <= MAX_FRAME_COLLISIONS, "No more room for collisions this frame!");
	
	GameClass_t *player = context->player;
	/*
	CollisionType col = object->hCollides_f(object, player->edata.x + BITE_OFFSET_X, player->edata.y + BITE_OFFSET_Y);
	if(col == COLLISION_FISH || col == COLLISION_HARM || col == COLLISION_DEATH) {
		frame_collisions[frame_collision_head++] = object;
	}
	*//*
	CollisionType col = entity_data(object, collision);
	int bite_x = entity_data(player, pos.x) + BITE_OFFSET_X;
	int bite_y = entity_data(player, pos.y) + BITE_OFFSET_Y;
	int y_mid = entity_data(player, pos.y) + MID_OFFSET_Y;
	int x2 = entity_data(player, pos.x) + X_MID;
	// if it's a edible
	if(col == COLLISION_FISH || col == COLLISION_POISON) {
		if( object->hCollides_f(object, bite_x, bite_y) ) {
			frame_collisions[frame_collision_head++] = object;
		}
	}
	else if(col == COLLISION_HARM || col == COLLISION_DEATH) {
		if( object->hCollides_f(object, entity_data(player, pos.x), y_mid) ||
			 object->hCollides_f(object, x2, y_mid) ) {
				frame_collisions[frame_collision_head++] = object;
		}
	}*/
	
	int bite_x = entity_data(player, pos.x) + BITE_OFFSET_X;
	int bite_y = entity_data(player, pos.y) + BITE_OFFSET_Y;
	// ok so this 5 is a magic number but just roll with it
	int bite_y2 = entity_data(player, pos.y) + BITE_OFFSET_Y - 5;
	if( SDL_HasIntersection(&(entity_data(object, pos)), &(entity_data(player, pos))) == SDL_TRUE ) {
		CollisionType col = entity_data(object, collision);
		if(col == COLLISION_FISH || col == COLLISION_POISON) {
			debug("Hello there fishy - x,y: %d,%d / w,h: %d,%d AGAINST: %d,%d.", entity_data(object, pos.x), entity_data(object, pos.y),
				entity_data(object, pos.w), entity_data(object, pos.h), bite_x, bite_y);
			if( object->hCollides_f(object, bite_x, bite_y) != COLLISION_NULL || object->hCollides_f(object, bite_x, bite_y2) != COLLISION_NULL ) {
				debug("Nom nom nom.");
				frame_collisions[frame_collision_head++] = object;
			}
		}
		else if(col == COLLISION_HARM || col == COLLISION_DEATH) {
			frame_collisions[frame_collision_head++] = object;
		}
	}
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Player_ClearCollisions(void)
{
	int i;
	for(i = 0; i < frame_collision_head; i++) {
		frame_collisions[i] = NULL;
	}
	
	frame_collision_head = 0;
	return R_SUCCESS;
}



// ~~~~~~~~~~~
//  instance methods
// ~~~~~~~~~~~
 
RETURNV PlayerShark_Update(GameClass_t *self, World_t *world) 
{ 

	float dx;
	float dy;
	int i;
	
	// check direcitonal inputs
	//  (i hate this but it's also very simple)
	if(input[0] == 1) {
		dy = -SPEED_VERT;
	}
	else if(input[1] == 1) {
		dy = SPEED_VERT;
	}
	if(input[2] == 1) {
		dx = -SPEED_HORZ;
	}
	else if(input[3] == 1) {
		dx = SPEED_HORZ;
	}
	
	// check if the bite key is held
	if(input[4] == 1) {
		// if we aren't biting, the bite timer is 0 AND we've released the key since our last bite...
		if(obj_data(self, is_biting) == 0 && obj_data(self, bite_reset) <= 0 && 
		 obj_data(self, bite_release) == 1) {
			// set our biting flag
			obj_data(self, is_biting) = 1;
			// reset the timer
			obj_data(self, bite_timer) = BITE_MAX_HOLD;
			// update our sprite
			Image_SetSprite(&(self->edata.image), obj_data(self, bite_sprite));
			// set the flag for releasing the key to off
			obj_data(self, bite_release) = 0;
		}
	}
	
	else {
		// otherwise, if we're biting and the key isn't held
		if(obj_data(self, is_biting)) {
			// we aren't biting any more
			obj_data(self, is_biting) = 0;
			obj_data(self, bite_timer) = 0;
			Image_SetSprite(&(self->edata.image), obj_data(self, swim_sprite));
			obj_data(self, bite_reset) = BITE_TIME_RESET;
		}
		// update the flag to say we've released the key
		obj_data(self, bite_release) = 1;
	}
	
	// if we are biting
	if(obj_data(self, is_biting) == 1)  {
		// reduce the timer
		obj_data(self, bite_timer)--;
		// if the timer is less than 0, we are no longer biting
		if(obj_data(self, bite_timer) <= 0) {
			obj_data(self, is_biting) = 0;
			Image_SetSprite(&(self->edata.image), obj_data(self, swim_sprite));
			obj_data(self, bite_reset) = BITE_TIME_RESET;
		}
	}
	
	// more timers
	if(obj_data(self, bite_reset) >= 0) {
		obj_data(self, bite_reset)--;
	}
	if(obj_data(self, hit_buffer) >= 0) {
		obj_data(self, hit_buffer)--;
	}
	
	// handle reported collisions
	for(i = 0; i < frame_collision_head; i++) {
		GameClass_t *o = frame_collisions[i];
		// if the target is dead, do nothing
		if( o->edata.is_dead != 0 ) {
			continue;
		}
		
		// if it's a fish and we're biting, "eat" the fish
		//  (updating the score is done on the fish end for some reason)
		if(entity_data(o, collision) == COLLISION_FISH && obj_data(self, is_biting)) {
			entity_data(o, is_dead) = 1;
			((Fish_t*)o->objData)->eaten = 1;
		}
		
		// if it's something that will hurt us on contact, and it's been enough frames
		//  since our last hit
		else if(entity_data(o, collision) == COLLISION_HARM && obj_data(self, hit_buffer) <= 0) {
			// do damage and reset the timer
			obj_data(self, health) -= 1;
			obj_data(self, hit_buffer) = HIT_BUFFER_RESET;
			log_info("Ow! %d", obj_data(self, health));
		}
		// otherwise if it's (poison AND we're biting), or if it's a contact death
		else if((entity_data(o, collision) == COLLISION_POISON && obj_data(self, is_biting)) || 
			entity_data(o, collision) == COLLISION_DEATH) {
			// dead
			obj_data(self, health) = 0;
		}

	}
	
	// update important variables
	entity_data(self, pos.y) += dy;
	entity_data(self, pos.x) += dx;
	
	if( entity_data(self, pos.x) < PLAYER_X_MIN) {
		entity_data(self, pos.x) = PLAYER_X_MIN;
	}
	else if( entity_data(self, pos.x) > PLAYER_X_MAX) {
		entity_data(self, pos.x) = PLAYER_X_MAX;
	}
	if( entity_data(self, pos.y) < PLAYER_Y_MIN) {
		entity_data(self, pos.y) = PLAYER_Y_MIN;
	}
	else if( entity_data(self, pos.y) > PLAYER_Y_MAX) {
		entity_data(self, pos.y) = PLAYER_Y_MAX;
	}
	
	if( obj_data(self, health) < 0 ) {
		obj_data(self, health) = 0;
	}
	update_sprite_position(self);
	return R_SUCCESS; 
} 
 
 
RETURNV PlayerShark_Anim(GameClass_t *self) 
{ 
 
	return R_SUCCESS; 
} 
 
 
RETURNV PlayerShark_LogDump(GameClass_t *self) 
{ 
 
	return R_SUCCESS; 
} 
 
 
RETURNV PlayerShark_Init(GameClass_t *self, va_list args) 
{ 
	void *scan = va_arg(args, void*);
	check_param(scan, PlayerShark, "Start X");
	int sx = *((int*)scan);
	
	scan = va_arg(args, void*);
	check_param(scan, PlayerShark, "Start Y");
	int sy = *((int*)scan);
	
	#ifdef CF_CHECK_STRICT
	scan = va_arg(args, void*);
	check(scan == NULL, "Bad parameter list passed to Shark initialisation!");
	#endif
	
	self->objData = malloc(sizeof(PlayerShark_t));
	
	Sprite_t *player_sprite = Image_Get_Sprite("shark_idle", HANDLE_NULL);
	check(player_sprite != NULL, "Could not get shark_idle sprite!");
	check( Image_SetSprite(&(self->edata.image), player_sprite) == R_SUCCESS, "Failed to set sprite data!" );
	
	entity_data(self, pos.x) = sx;
	entity_data(self, pos.y) = sy;
	update_sprite_position(self);
	
	obj_data(self, bite_release) = 1;
	
	obj_data(self, swim_sprite) = Image_Get_Sprite("shark_idle", HANDLE_NULL);
	obj_data(self, bite_sprite) = Image_Get_Sprite("shark_bite", HANDLE_NULL);
	check(obj_data(self, swim_sprite) != NULL, "Failed to get swimmiing sprite.");
	check(obj_data(self, bite_sprite) != NULL, "Failed to get biting sprite.");
	
	entity_data(self, pos.w) = PLAYER_HITBOX_WIDTH;
	entity_data(self, pos.h) = PLAYER_HITBOX_HEIGHT;
	entity_data(self, sprite_offset_x) = PLAYER_SPRITE_OFFSET_X;
	entity_data(self, sprite_offset_y) = PLAYER_SPRITE_OFFSET_Y;
	
	obj_data(self, health) = HP_START;
	obj_data(self, hit_buffer) = 0;
	
	return R_SUCCESS;
error:
	return R_FAIL;
} 
 
 
RETURNV PlayerShark_EntityData(GameClass_t *self, EntityData_t **out) 
{ 
 
	return R_SUCCESS; 
} 
 
 
RETURNV PlayerShark_MemoryFree(GameClass_t *self) 
{ 
 
	return R_SUCCESS; 
} 
 
 
CollisionType PlayerShark_Collides(GameClass_t *self, float x, float y)
{
	if(x >= entity_data(self, pos.x) && x < entity_data(self, pos.x) + entity_data(self, pos.w) &&
		y >= entity_data(self, pos.y) && y < entity_data(self, pos.y) + entity_data(self, pos.h)) {
		return COLLISION_PLAYER;
	}
	
	else {
		return COLLISION_NULL;
	}
}
 
 
 
CLASS_DEFINE(PlayerShark) { 
	CLASS_UPDATE(PlayerShark, PlayerShark_Update); 
	CLASS_ANIM(PlayerShark, PlayerShark_Anim); 
	CLASS_INIT(PlayerShark, PlayerShark_Init); 
	CLASS_LOG(PlayerShark, PlayerShark_LogDump); 
	CLASS_FREE(PlayerShark, PlayerShark_MemoryFree); 
	CLASS_COLLISION(PlayerShark, PlayerShark_Collides);
	CLASS_GEN_TYPEID(PlayerShark); 
	CLASS_CHECKID(PlayerShark); 
	CLASS_END(PlayerShark); 
} 
