#include "fish.h" 
#include "../object.h" 
#include "../world.h" 
#include "../ashare/dbg.h" 
#include "../ashare/share_utils.h" 
#include "../ashare/share_base.h" 
#include "../global_def.h" 
 
#include <stdarg.h> 
#include <stdlib.h>

#define entity_data(o, f) o->edata.f
#define obj_data(o, f) ((Fish_t*)o->objData)->f

static const int FISH_SPAWN_DEFAULT = WORLD_WIDTH;


struct fishdata_extra_s {
	int ai_type;
	CollisionType col;
	int is_animated;
	SpriteData_t *sprite;
	SDL_Rect col_data;
};


static Fish_t *fish_templates = NULL;
static int fish_max = -1;
static char **fish_type_names;
static struct fishdata_extra_s *fish_extra = NULL;
static int fish_counter = 0;

static int fish_load_safe = 0;

static RETURNV (*fish_behavior[100])(GameClass_t*, World_t*);
static int ai_type_counter = 0;

#include "fish_ai.h"

static FishType Fish_FindType(const char *fish_name)
{
	int i = 0;
	int id = -1;
	for( i = 0; i < fish_counter; i++ ) {
		if( strcmp(fish_name, fish_type_names[i]) == 0 ) {
			id = i;
			break;
		}
	}
	
	check(id >= 0, "Could not find fish: %s.", fish_name);
	return id;
error:
	return -1;
}

RETURNV Fish_Load_Init(int fish_types)
{
	check(fish_templates == NULL, "Cannot initialise data that already exists!");
	check(fish_types > 0, "Invalid parameter for number of fish!");
	check(fish_load_safe == 0, "Invalid loading state for fish data!");
	
	fish_templates = calloc(fish_types, sizeof(Fish_t));
	fish_extra = calloc(fish_types, sizeof(struct fishdata_extra_s));
	fish_type_names = malloc(fish_counter * sizeof(char *));
	fish_max = fish_types;
	fish_counter = 0;
	fish_load_safe = 1;
	
	fish_behavior[ai_type_counter++] = &fish_ai_null;
	fish_behavior[ai_type_counter++] = &fish_ai_horiz;
	fish_behavior[ai_type_counter++] = &fish_ai_sine;
	fish_behavior[ai_type_counter++] = &fish_ai_sword;
	fish_behavior[ai_type_counter++] = &fish_ai_crab;
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Fish_Load(const char *name, int animated, const char *sprite_name, 
	int width, int height, int offset_x, int offset_y, int ai_type, float speed, 
	float speed2, int points, CollisionType col)
{
	check(fish_templates != NULL && fish_type_names != NULL && fish_extra != NULL, 
		"Arrays are NULL, check Fish_Data_Init() is called.");
	check(fish_load_safe == 1, "Invalid Fish loading state.");
	check(animated == 0 || animated == 1, "Invalid value for parameter: 'animated'");
	check(ai_type >= 0, "Invalid value for parameter: 'ai_type'");
	check(fish_counter < fish_max, "Not enough room for new fish type.");
	
	// do the name string thing
	fish_type_names[fish_counter] = malloc(strlen(name) * sizeof(char));
	check_mem(fish_type_names[fish_counter]);
	strcpy( fish_type_names[fish_counter], name );
	
	// setup object data
	Fish_t *target = &(fish_templates[fish_counter]);
	struct fishdata_extra_s *extra = &(fish_extra[fish_counter]);
	target->speed = speed;
	target->speed2 = speed2;
	target->point_value = points;
	target->eaten = 0;
	
	extra->ai_type = ai_type;
	extra->col = col;
	extra->is_animated = animated;
	extra->col_data.x = offset_x;
	extra->col_data.y = offset_y;
	extra->col_data.w = width;
	extra->col_data.h = height;
	
	// do the image part, impotant!
	SpriteData_t *sprite = NULL;
	if(animated == 0) {
		sprite = Image_Get_Sprite(sprite_name, HANDLE_NULL);
		
	}
	else {
		sprite = Image_Get_Animation(sprite_name, HANDLE_NULL);
	}
	
	check (sprite != NULL, "Failed to get sprite data for fish!");
	extra->sprite = sprite;
	fish_counter++;
	
	debug("Loaded new fish %s, Speed: %f, Speed2: %f", name, speed, speed2);
	
	return R_SUCCESS;
error:
	log_err("Could not load Fish: %s", name);
	return R_FAIL;
}


RETURNV Fish_Remake(GameClass_t *fish, World_t *world, int index, int sy, const char *type)
{
	check(fish != NULL && world != NULL, "Bad memory.");
	check(index >= 0 && index < world->max_fish, "Invalid index value.");
	check( type != NULL, "Invalid fish type - cannot be NULL! (this is impossible)");
	
	debug("Remaking fish, type: %s..", type);
	debug_flush();
	
	FishType type_id = Fish_FindType(type);
	check(type_id >= 0, "Failed to find fish %s", type);
	memcpy( fish->objData, fish_templates + type_id, sizeof(Fish_t) );
	struct fishdata_extra_s extra = fish_extra[type_id];
	
	#ifdef CF_CHECK_SOME
	check( extra.ai_type >= 0 && extra.ai_type < ai_type_counter, "Invalid AI type in fish template!");
	#endif
	
	obj_data(fish, fid) = index;
	fish->hUpdate_f = fish_behavior[extra.ai_type];
	
	Image_SetSprite(&(fish->edata.image), extra.sprite);
	debug("Set Fish sprite data: wx:%d, wy:%d, ix:%d, iy:%d, iw:%d, ih:%d",
		fish->edata.image.world_position.x, fish->edata.image.world_position.y,
		fish->edata.image.image_position.x, fish->edata.image.image_position.y,
		fish->edata.image.image_position.w, fish->edata.image.image_position.h);
		
	entity_data(fish, pos.y) = sy + (entity_data(fish, image).image_position.h/2);
	entity_data(fish, collision) = extra.col;
	
	entity_data(fish, pos.w) = extra.col_data.w;
	entity_data(fish, pos.h) = extra.col_data.h;
	entity_data(fish, sprite_offset_x) = extra.col_data.x;
	entity_data(fish, sprite_offset_y) = extra.col_data.y;
	//entity_data(fish, x) = (entity_data(fish, width) > 100 ? entity_data(fish, width) : FISH_SPAWN_DEFAULT);
	entity_data(fish, pos.x) = FISH_SPAWN_DEFAULT;
	
	update_sprite_position(fish);
	
	entity_data(fish, is_dead) = 0;
	
	world->fish_array_active[index] = 1;
	debug("Remade Fish - Speed: %f, Speed2: %f", obj_data(fish, speed), obj_data(fish, speed));
	debug_flush();
	return R_SUCCESS;
error:
	return R_FAIL;
}


RETURNV Fish_FreeAll(void)
{
	if(fish_templates) free(fish_templates);
	if(fish_type_names) {
		int i;
		for( i = 0; i < fish_counter; i++) {
			if(fish_type_names[i]) free(fish_type_names[i]);
		}
		free(fish_type_names);
	}
	
	if(fish_extra) free(fish_extra);
	
	return R_SUCCESS;
}


// ~~~~~
// CLASS METHODS
// ~~~~
 
RETURNV Fish_Update(GameClass_t *self, World_t *world) 
{ 
	
	if (self->edata.is_dead != 0) {
		//debug("Killed fish.");
		world->fish_array_active[obj_data(self, fid)] = 0;
		world->fish_count--;
		if(obj_data(self, eaten) == 1)
			world->player_score += obj_data(self, point_value);
	}

	
	obj_data(self, lifetime)++;
	update_sprite_position(self);
	self->hAnim_f(self);
	//debug("And i cleanup - sprite x: %d, intended: %d", self->edata.image.world_position.x, (int) self->edata.x);
	
	return R_SUCCESS;
error:
	return R_FAIL;
} 
 
 
RETURNV Fish_Anim(GameClass_t *self) 
{ 
	// do we actually need to animate anything?
	if(self->edata.image.in_animation == 0) return R_SUCCESS;
	
	// increment the frame counter, the basic part of animation
	entity_data(self, image).frame_counter++;
	// if our frame time is equal to the time for this frame
	if( entity_data(self, image).frame_counter < 0 ) {
	
		check( entity_data(self, image).current_frame->next != NULL,
			"Bad next-sprite pointer in Animation." );
		
		// ew
		// set the sprite data to the next frame
		Image_SetSprite( &(entity_data(self, image)), entity_data(self, image).current_frame->next );
		// reset the timer fomr the spritedata
		entity_data(self, image).frame_counter = entity_data(self, image).current_frame->anim_time;
	}
	
	return R_SUCCESS; 
error:
	return R_FAIL;
} 
 
 
RETURNV Fish_LogDump(GameClass_t *self) 
{ 
	
	log_info("Object dump for Class: %s", Object_GetClassString(self->type));
	log_info("  Base Data - ID: %d, x: %f, y: %f", self->id, entity_data(self, pos.x), entity_data(self, pos.y));
	log_info("   Width: %f, Height: %f, Collision ID: %s", 
		entity_data(self, pos.w), entity_data(self, pos.h), collision_string(entity_data(self, collision)));
	log_info("   Age: %d ticks, Points: %d", obj_data(self, lifetime), obj_data(self, point_value));
	log_info("   Speed: %f, Speed2: %f", obj_data(self, speed), obj_data(self, speed2));
	check_collision_valid(entity_data(self, collision));
	return R_SUCCESS; 
error:
	return R_SUCCESS;
} 
 
 
RETURNV Fish_Init(GameClass_t *self, va_list args) 
{ 
 
	self->objData = malloc(sizeof(Fish_t));
	check_mem(self->objData);
	
	char* arg_read = va_arg(args, char*);
	check_param(arg_read, Fish, "Start Y");
	int sy = *((int*) arg_read);
	
	const char *type = va_arg(args, const char*);
	check_param(type, Fish, "FishType");
	
	#ifdef CF_CHECK_STRICT
	// confirm that the list ends properly
	arg_read = va_arg(args, char*);
	check(arg_read == NULL, "Bad parameter list passed to Fish initialisation!");
	#endif
	
	FishType ft = Fish_FindType(type);
	// just copy the fucking data we need
	memcpy( self->objData, fish_templates + ft, sizeof(Fish_t) );
	// now setup the extra bits and bobs
	struct fishdata_extra_s extra = fish_extra[ft];
	#ifdef CF_CHECK_SOME
	check( extra.ai_type >= 0 && extra.ai_type < ai_type_counter, "Invalid AI type in fish template!");
	#endif
	
	self->hUpdate_f = fish_behavior[extra.ai_type];
	
	Image_SetSprite(&(self->edata.image), extra.sprite);
	entity_data(self, collision) = extra.col;
	
	entity_data(self, pos.w) = entity_data(self, image).image_position.w;
	entity_data(self, pos.h) = entity_data(self, image).image_position.h;
	//entity_data(self, pos.x) = (entity_data(self, pos.w) > 100 ? entity_data(self, pos.w) : FISH_SPAWN_DEFAULT);
	entity_data(self, pos.x) = 800;
	entity_data(self, pos.y) = sy;
	
	return R_SUCCESS;
error:
	if(self->objData)
		free(self->objData);
	return R_FAIL;
} 
 
 
RETURNV Fish_MemoryFree(GameClass_t *self) 
{ 
	if(self->objData)
		free(self->objData);

	return R_SUCCESS; 
} 


CollisionType Fish_Collides(GameClass_t *self, float x, float y)
{
	if(x >= entity_data(self, pos.x) && x < entity_data(self, pos.x) + entity_data(self, pos.w) &&
		y >= entity_data(self, pos.y) && y < entity_data(self, pos.y) + entity_data(self, pos.h)) {
		return entity_data(self, collision);
	}
	
	else {
		return COLLISION_NULL;
	}
}
 
 
CLASS_DEFINE(Fish) { 
	CLASS_UPDATE(Fish, Fish_Update); 
	CLASS_ANIM(Fish, Fish_Anim); 
	CLASS_INIT(Fish, Fish_Init); 
	CLASS_LOG(Fish, Fish_LogDump); 
	CLASS_FREE(Fish, Fish_MemoryFree); 
	CLASS_COLLISION(Fish, Fish_Collides);
	CLASS_GEN_TYPEID(Fish); 
	CLASS_CHECKID(Fish); 
	CLASS_END(Fish); 
} 
