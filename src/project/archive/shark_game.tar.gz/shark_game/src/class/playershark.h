#ifndef PH_SRC__CLASS_PlayerShark_H__ 
#define PH_SRC__CLASS_PlayerShark_H__ 
#include "../object.h" 
#include "../global_def.h"
CLASS_EXPORT(PlayerShark); 
typedef struct {
	int is_biting;
	int bite_timer;
	int bite_reset;
	int health;
	int bite_release;
	int hit_buffer;
	
	Sprite_t *swim_sprite;
	Sprite_t *bite_sprite;
} PlayerShark_t;

typedef enum {
	PLAYER_UP = 0,
	PLAYER_DOWN = 1,
	PLAYER_LEFT = 2,
	PLAYER_RIGHT = 3,
	PLAYER_BITE = 4,
	PLAYER_NONE = 5,
	COMMAND_SIZE = 6
} PLAYERCOMMAND;

RETURNV PlayerCommand(PLAYERCOMMAND c, int value);
RETURNV Player_CheckCollision(GameClass_t *object, World_t *context);
RETURNV Player_InputInit(void);
RETURNV Player_ClearCollisions(void);
#endif 
