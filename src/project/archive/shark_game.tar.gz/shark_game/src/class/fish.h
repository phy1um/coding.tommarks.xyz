#ifndef PH_SRC__CLASS_Fish_H__ 
#define PH_SRC__CLASS_Fish_H__ 
#include "../object.h" 
#include "../world.h"
#include "../global_def.h"

#define FishType int

//define obj_data(o, f) ((Fish_t*)((o)->objData))->(f)

//define entity_data(o, f) (o)->edata.(f)


CLASS_EXPORT(Fish); 

RETURNV Fish_Remake(GameClass_t *fish, World_t *world, int index, int sy, const char *type);

RETURNV Fish_Load_Init(int fish_types);
/*RETURNV Fish_Load(const char *name, int animated, const char *sprite_name, int ai_type, 
	float speed, float speed2, int points, CollisionType col);*/
	
RETURNV Fish_FreeAll(void);
	
static FishType Fish_FindType(const char *fish_name);


typedef struct fish_objdata_s {
	int lifetime;
	float speed;
	float speed2;
	int point_value;
	int eaten;
	int fid;
} Fish_t;

RETURNV Fish_Load_Init(int fish_types);

RETURNV Fish_Load(const char *name, int animated, const char *sprite_name, 
	int width, int height, int offset_x, int offset_y, int ai_type, float speed, 
	float speed2, int points, CollisionType col);
	
RETURNV Fish_Load_Done(void);

#endif 
