#ifndef PH_SRC__IMAGE_H__
#define PH_SRC__IMAGE_H__

#include <SDL2/SDL.h>
#include "ashare/dbg.h"
#include "global_def.h"

#define IMAGE_HANDLE ImageResource_t
#define SPRITE_HANDLE ImageResource_t
#define ANIM_HANDLE ImageResource_t
#define HANDLE_VALIDATE(h) check((h) >= 0, "Invalid sprite handle provided.")

#define ANIM_NONE -1
#define HANDLE_NULL -1


RETURNV Image_Init(int sprite_sheet_max, int sprites_max, int anims_max);
RETURNV Image_FreeAll(void);
// TODO: implement these
RETURNV Image_IsLoaded(void);


IMAGE_HANDLE Image_Get_SpriteSheet_Handle(const char *str);
SPRITE_HANDLE Image_Get_Sprite_Handle(const char *str);
ANIM_HANDLE Image_Get_Animation_Handle(const char *str);

SpriteData_t *Image_Get_Sprite(const char *str, SPRITE_HANDLE id);
SpriteData_t *Image_Get_Animation(const char *str, ANIM_HANDLE id);
SDL_Surface *Image_Get_SpriteSheet(const char *str, IMAGE_HANDLE id);

#ifdef PH_SRC__IMAGE_C__
	#ifdef _WIN32
	static ImageResource_t Image_search_array_for(char **arr, int size, const char *str);
	#else
	static inline ImageResource_t Image_search_array_for(char **arr, int size, const char *str);
	#endif
#endif


RETURNV Image_AddAnimation(const char *name, int frames_count, ...);
RETURNV Image_AddSprite(const char *name, IMAGE_HANDLE sprite_sheet, int image_x,
	int image_y, int image_w, int image_h);
RETURNV Image_LoadSpriteSheet(const char *path, const char *name, int alpha_on, 
	int alpha_r, int alpha_g, int alpha_b);

RETURNV Image_SetSprite(Sprite_t *sp, SpriteData_t *data);

#endif
