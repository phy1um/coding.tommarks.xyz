

RETURNV Phase_Test1_Init(Seq_Phase *phase, Seq_PhaseData *data, Wave_t *parent);
RETURNV Phase_Test1_Tick(Seq_Phase *self, World_t *world);

RETURNV Phase_Test2_Init(Seq_Phase *phase, Seq_PhaseData *data, Wave_t *parent);
RETURNV Phase_Test2_Tick(Seq_Phase *self, World_t *world);

RETURNV Phase_Test3_Init(Seq_Phase *phase, Seq_PhaseData *data, Wave_t *parent);
RETURNV Phase_Test3_Tick(Seq_Phase *self, World_t *world);

RETURNV Phase_Test4_Init(Seq_Phase *phase, Seq_PhaseData *data, Wave_t *parent);
RETURNV Phase_Test4_Tick(Seq_Phase *self, World_t *world);