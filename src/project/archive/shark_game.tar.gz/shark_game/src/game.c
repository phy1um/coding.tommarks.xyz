

#include <SDL2/SDL.h>

#include "global_def.h"
#include "image.h"
#include "object.h"
#include "world.h"

#include "ashare/share_base.h"
#include "ashare/share_utils.h"
#include "ashare/dbg.h"

#include "class/fish.h"
#include "class/playershark.h"


#define WINDOW_TITLE "Shark Game"
#define GAME_FPS 60
#define CLOCK_RES 1000

#define SCORE_DIGIT_COUNT 6
#define SCORE_X 30
#define SCORE_Y 25
#define SCORE_FONT_WIDTH 10
#define SCORE_FONT_HEIGHT 12

const uint32_t FRAME_TIME = CLOCK_RES/GAME_FPS;
const uint32_t LOG_FRAME_DELAY = GAME_FPS*5;
static const char *LOG_FILE_NAME = "run.log";

char *collision_names[COLLISION_MAX];

static SDL_Window *window = NULL;

#define BIND_UP SDLK_w:case SDLK_UP
#define BIND_DOWN SDLK_s:case SDLK_DOWN
#define BIND_LEFT SDLK_a:case SDLK_LEFT
#define BIND_RIGHT SDLK_d:case SDLK_RIGHT

#define BIND_BITE SDLK_SPACE


static RETURNV Main_StartObj(void);
static RETURNV Main_StartImage(void);
static RETURNV Main_LoadFish(void);

static RETURNV Main_CloseAll(void);

static RETURNV Main_InitWindow(SDL_Surface **hScreen);

#ifdef _WIN32
#include <windows.h>
int WINAPI WinMain(HINSTANCE hI, HINSTANCE hPrev, LPSTR lpCmd, int CmdShow)
#else
int main()
#endif
{
	RETURNV rv = R_SUCCESS;
	PlayerShark_t *player = NULL;
	SDL_Surface *generic_background = NULL, *screen = NULL;
	int loop=0, log_frames=0, pause=0, drawbox=0, wave_i = 0;
	uint32_t next_frame = 1;
	SDL_Event ev;
	SDL_Event exit = {0};
	exit.type = SDL_QUIT;
	#ifdef CF_DEV
	SDL_Renderer *hitbox_renderer = NULL;
	#endif
	int score_array[SCORE_DIGIT_COUNT] = {0};
	SDL_Rect score_position = {.x = SCORE_X, .y = SCORE_Y, 
		.w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT};
		
	SDL_Rect TMP_health_position = {.x = 400, .y = SCORE_Y,
		.w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT};
	
	int stral = 0;
	for( stral = 0; stral < COLLISION_MAX; stral++ ) {
		collision_names[stral] = malloc(100);
	}
	
	strcpy(collision_names[0], "COLLISION_NULL");
	strcpy(collision_names[1], "COLLISION_PLAYER");
	strcpy(collision_names[2], "COLLISION_FISH");
	strcpy(collision_names[3], "COLLISION_DEATH");
	strcpy(collision_names[4],"COLLISION_HARM");
	strcpy(collision_names[5],"COLLISION_POISON");
	
	log_init("startup.log", "w");
	log_info("Starting up...");
	log_flush();
	
	Player_InputInit();
	
	int rc = SDL_Init(SDL_INIT_VIDEO);
	check(rv >= 0, "Failed to initialise SDL. Err #%d: %s", rc, SDL_GetError());
	log_info("Started SDL systems.");
	log_flush();
	
	rv = Main_InitWindow(&screen);
	check(rv == R_SUCCESS, "Failed to initialise game window/screen.");
	log_info("Created Window and SDL Surfaces.");
	log_flush();
	
	rv = Main_StartImage();
	check(rv == R_SUCCESS, "Failed to initialise image module data.");
	log_info("Started Image systems.");
	log_flush();
	
	rv = Main_StartObj();
	check(rv == R_SUCCESS, "Failed to initialise oject module data.");
	log_info("Started Object systems.");
	log_flush();
	
	rv = Main_LoadFish();
	check(rv == R_SUCCESS, "Failed to load fish data!");
	log_info("Loaded Fish data!");
	log_flush();
	
	World_t game_world = {0};
	rv = World_Create(&game_world, 120);
	check(rv == R_SUCCESS, "Failed to create game world.");
	log_info("Initialised Game world.");
	log_flush();
	
	rv = World_SpawnPlayer(&game_world, 0, WORLD_HEIGHT/2);
	check(rv == R_SUCCESS, "Could not spawn player.");
	log_info("Created Player in world.");
	log_flush();
	
	player = (PlayerShark_t *)(game_world.player->objData);
	check(player != NULL, "Failed to initialise player properly!");
	
	generic_background = Image_Get_SpriteSheet("background1", HANDLE_NULL);
	
	SDL_Surface *font_sprite_sheet = Image_Get_SpriteSheet("font", HANDLE_NULL);
	SDL_Rect font_numbers[10] = {
		{.x=0, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=2*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=3*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=4*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=5*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=6*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=7*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=8*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
		{.x=9*SCORE_FONT_WIDTH, .y=0, .w = SCORE_FONT_WIDTH, .h = SCORE_FONT_HEIGHT},
	};
	
	#ifdef CF_DEV
	hitbox_renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	check(hitbox_renderer != NULL, "Failed to create hitbox SDL Renderer!");
	//rv = SDL_SetRenderDrawBlendMode(hitbox_renderer, SDL_BLENDMODE_BLEND);
	//check(rv == R_SUCCESS, "SDL_SetRenderDrawBlendMode() failed: %s", SDL_GetError());
	rv = SDL_SetRenderDrawColor(hitbox_renderer, 255, 0, 0, 255);
	check(rv == R_SUCCESS, "SDL_SetRenderDrawColor() failed: %s", SDL_GetError());
	#endif
	
	log_end();
	log_init(LOG_FILE_NAME, "w");
	log_info("Starting up...");
	log_flush();
	
	loop = 1;
	GameClass_t *entity_list;
	int *active_flags;
	int ecount = 0;
	int i = 0;
	
	while(loop) {
		
		while( SDL_PollEvent(&ev) ) {
			if(ev.type == SDL_QUIT) {
				loop = 0;
				log_info("Quit message recieved.");
				log_flush();
			}
			
			else if(ev.type == SDL_KEYDOWN) {
				switch(ev.key.keysym.sym) {
					case SDLK_p:
						if(pause) {
							pause = 0;
							log_init(LOG_FILE_NAME, "a");
						}
						else {
							pause = 1;
							log_info("Score: %d", game_world.player_score);
							log_flush();
							log_end();
						}
						break;
						
					#ifdef CF_DEV
					case SDLK_c:
						if(drawbox) {
							drawbox = 0;
						}
						else {
							drawbox = 1;
						}
						break;
					#endif
					
					case BIND_UP:
						PlayerCommand(PLAYER_UP, 1);
						break;
						
					case BIND_DOWN:
						PlayerCommand(PLAYER_DOWN, 1);
						break;
						
					case BIND_LEFT:
						PlayerCommand(PLAYER_LEFT, 1);
						break;
						
					case BIND_RIGHT:
						PlayerCommand(PLAYER_RIGHT, 1);
						break;
						
					case BIND_BITE:
						PlayerCommand(PLAYER_BITE, 1);
						break;
					
					case SDLK_ESCAPE:
						SDL_PushEvent(&exit);
						break;
						
						
					case SDLK_1:
						World_SpawnFish(&game_world, 200, "horiz_slow");
						break;
						
					case SDLK_2:
						World_SpawnFish(&game_world, 200, "horiz_med");
						break;
						
					case SDLK_3:
						World_SpawnFish(&game_world, 200, "horiz_fast");
						break;
						
					case SDLK_4:
						World_SpawnFish(&game_world, 200, "sine_slow");
						break;
						
					case SDLK_5:
						World_SpawnFish(&game_world, 20, "sine_wide");
						break;
						
					case SDLK_6:
						World_SpawnFish(&game_world, 200, "sword");
						break;
						
					case SDLK_7:
						World_SpawnFish(&game_world, 200, "puffer");
						break;
						
					case SDLK_8:
						World_SpawnFish(&game_world, 600, "crab");
						break;
						
					case SDLK_h:
						player->health += 1;
						break;
						
					default:
						break;
				}
			}
			
			else if (ev.type == SDL_KEYUP) {
				switch(ev.key.keysym.sym) {
					case BIND_UP:
						PlayerCommand(PLAYER_UP, 0);
						break;
						
					case BIND_DOWN:
						PlayerCommand(PLAYER_DOWN, 0);
						break;
						
					case BIND_LEFT:
						PlayerCommand(PLAYER_LEFT, 0);
						break;
						
					case BIND_RIGHT:
						PlayerCommand(PLAYER_RIGHT, 0);
						break;
						
					case BIND_BITE:
						PlayerCommand(PLAYER_BITE, 0);
						break;
						
					default:
						break;
				}
			}
			
		}
		
		if( SDL_TICKS_PASSED(SDL_GetTicks(), next_frame) ) {
			SDL_BlitSurface(generic_background, NULL, screen, NULL);
			#ifdef CF_DEV
			if(drawbox) {
				SDL_SetRenderDrawColor(hitbox_renderer, 0, 0, 0, 255);
				SDL_RenderClear(hitbox_renderer);
				SDL_SetRenderDrawColor(hitbox_renderer, 255, 0, 0, 255);
			}
			#endif
			
			rv = World_BeginFrame(&game_world);
			check(rv == R_SUCCESS, "Failed to initialise world data for new frame.");
			rv = World_GetEntityList(&game_world, &entity_list, &active_flags, &ecount);
			check(rv == R_SUCCESS, "Failed to get entity list from World.");
			
			GameClass_t target;
			for( i = 0; i < ecount; i++ ) {
				if( active_flags[i] == 1 ) {
					target = entity_list[i];
					if(!pause) {
						target.hUpdate_f(entity_list + i, &game_world);
					}
					SDL_BlitSurface(
						target.edata.image.sprite_sheet,
						&(target.edata.image.image_position),
						screen,
						&(target.edata.image.world_position)
					);
					#ifdef CF_DEV
					if(drawbox) { 
						//log_info("Drawing Rect: %d, %d, %d, %d", target.edata.pos.x, target.edata.pos.y, 
						//	target.edata.pos.w, target.edata.pos.h);
						rv = SDL_RenderFillRect(hitbox_renderer, &(target.edata.pos));
						check(rv == R_SUCCESS, "Could not draw rect!");
					}
					#endif
					if(!pause) {
						Player_CheckCollision(&(entity_list[i]), &game_world);
					}
				}
			}
			
			#ifdef CF_CHECK_STRICT
			check(score_array != NULL, "Invalid array for score values. This is fatal!");
			#endif
			rv = World_GetScoreAsArray(game_world.player_score, score_array, SCORE_DIGIT_COUNT);
			check(rv == R_SUCCESS, "Bad data from World_GetScoreAsArray()!");
			score_position.x = SCORE_X;
			for(i = SCORE_DIGIT_COUNT - 1; i >= 0; i--) {
				SDL_BlitSurface(
					font_sprite_sheet,
					&(font_numbers[score_array[i]]),
					screen,
					&score_position);
				score_position.x += SCORE_FONT_WIDTH;
			}
			
			if(player->health >= 0 && player->health <= 9) {
				SDL_BlitSurface(
						font_sprite_sheet,
						&(font_numbers[player->health]),
						screen,
						&TMP_health_position);
			}
			
			
			if( --log_frames <= 0 ) {
				log_info("Score: %d", game_world.player_score);
				log_flush();
				log_frames = LOG_FRAME_DELAY;
			}
			
			/*if((game_world.ticks % 90) == 0) {
				//debug("Do fish spawn?");
				World_SpawnFish(&game_world, 350, "sword");
			}
			if(((game_world.ticks+1) % 60) == 0) {
				debug("Do fish spawn?");
				World_SpawnFish(&game_world, 200, "puffer");
			}
			if((game_world.ticks % 30) == 0) {
				//debug("Do fish spawn?");
				World_SpawnFish(&game_world, 300, "horiz_med");
			}*/
			
			next_frame = SDL_GetTicks() + FRAME_TIME;
			game_world.ticks++;
			#ifdef CF_DEV
			if(drawbox) {
				SDL_RenderPresent(hitbox_renderer);
			} else {
				SDL_UpdateWindowSurface(window);
			}
			#else
			SDL_UpdateWindowSurface(window);
			#endif
			//SDL_Delay(2);
		}
		
	}
	
	log_info("Successfully reached end of execution.");
	log_flush();
error:
	log_info("Closing down systems.");
	log_flush();
	if(screen) SDL_FreeSurface(screen);
	World_Destroy(&game_world);
	Main_CloseAll();
	return rv;
}



static RETURNV Main_StartImage(void)
{
	RETURNV rv = R_SUCCESS;
	Image_Init(10, 100, 100);
	log_info(" Initialised core image data.");
	debug_flush();
	
	rv = Image_LoadSpriteSheet("shark.bmp", "shark", 1, 255, 0, 255);
	check(rv == R_SUCCESS, "");
	rv = Image_LoadSpriteSheet("back.bmp", "background1", 0, -1, -1, -1);
	check(rv == R_SUCCESS, "");
	rv = Image_LoadSpriteSheet("fish_01.bmp", "fish1", 1, 255, 0, 255);
	check(rv == R_SUCCESS, "");
	rv = Image_LoadSpriteSheet("font.bmp", "font", 1, 255, 0, 255);
	check(rv == R_SUCCESS, "");
	
	log_info(" Loaded sprite sheet data.");
	debug_flush();
	
	IMAGE_HANDLE shark_h = Image_Get_SpriteSheet_Handle("shark");
	HANDLE_VALIDATE(shark_h);
	debug_flush();
	rv = Image_AddSprite("shark_idle", shark_h, 0, 40, 110, 40);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("shark_bite", shark_h, 0, 0, 110, 40);
	check(rv == R_SUCCESS, "");
	
	log_info(" Creating Sprites from data.");
	debug_flush();
	
	IMAGE_HANDLE fish_h = Image_Get_SpriteSheet_Handle("fish1");
	HANDLE_VALIDATE(fish_h);
	rv = Image_AddSprite("fish_pink", fish_h, 0, 0, 32, 14);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_barri", fish_h, 0, 14, 38, 9);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_sword", fish_h, 0, 182, 50, 9);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_crab", fish_h, 0, 28, 31, 21);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_puffer", fish_h, 0, 56, 31, 24);
	check(rv == R_SUCCESS, "");
	
	rv = Image_AddSprite("fish_slow", fish_h, 38, 0, 35, 14);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_purp", fish_h, 38, 14, 30, 13);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_red", fish_h, 38, 28, 34, 11);
	check(rv == R_SUCCESS, "");
	rv = Image_AddSprite("fish_green", fish_h, 38, 42, 32, 15);
	check(rv == R_SUCCESS, "");
	
	log_info(" All loaded, finishing.");
	debug_flush();
	
	return R_SUCCESS;
	
error:
	return R_FAIL;
}


static RETURNV Main_StartObj(void)
{
	RETURNV rv = R_SUCCESS;
	
	rv = Object_Begin();
	check_assert(rv == R_SUCCESS);
	
	CLASS_SETLOAD(Fish);
	CLASS_SETLOAD(PlayerShark);
	
	rv = Object_LoadClasses();
	check_assert(rv == R_SUCCESS);
	
	return R_SUCCESS;
error:
	return R_FAIL;
}


static RETURNV Main_InitWindow(SDL_Surface **hScreen)
{
	debug("I reach this point.");
	debug_flush();
	if( *hScreen ) log_warn("Screen handle parameter should be NULL - check initialisation.");
	
	window = SDL_CreateWindow(WINDOW_TITLE, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		WORLD_WIDTH, WORLD_HEIGHT, SDL_WINDOW_SHOWN);
	check(window != NULL, "Failed to initialise SDL_Window: %s", SDL_GetError());
	
	debug("Boop.");
	debug_flush();
	
	*hScreen = SDL_GetWindowSurface(window);
	check(*hScreen != NULL, "Failed to initialise SDL_Surface as a screen: %s", SDL_GetError());
	
	debug("I reach the end of this point.");
	debug_flush();
	return R_SUCCESS;
error:
	return R_FAIL;
}


static RETURNV Main_LoadFish(void)
{
	RETURNV rv = R_SUCCESS;
	debug("Starting fish load...");
	debug_flush();
	rv = Fish_Load_Init(10);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("FishDead", 0, "fish_pink", 32, 10, 0, -2, 0, 0, 0, 0, COLLISION_NULL);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("horiz_slow", 0, "fish_slow", 25, 14, 0, 0, 1, 4.8, 1, 10, COLLISION_FISH);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("horiz_med", 0, "fish_red", 34, 11, 0, 0, 1, 6.6, 1, 50, COLLISION_FISH);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("horiz_fast", 0, "fish_purp", 30, 13, 0, 0, 1, 9.8, 1, 300, COLLISION_FISH);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("sine_slow", 0, "fish_barri", 38, 9, 0, 0, 2, 7.6, 2.3, 100, COLLISION_FISH);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("sine_wide", 0, "fish_green", 32, 15, 0, 0, 2, 7, 18, 800, COLLISION_FISH);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("sword", 0, "fish_sword", 40, 5, -10, -1, 3, 9, 60, 0, COLLISION_HARM);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("crab", 0, "fish_crab", 25, 14, -3, -1, 4, 4, 0, 0, COLLISION_HARM);
	check_assert(rv == R_SUCCESS);
	rv = Fish_Load("puffer", 0, "fish_puffer", 20, 14, -4, -5, 1, 3, 1, 0, COLLISION_POISON);
	check_assert(rv == R_SUCCESS);

	return R_SUCCESS;
error:
	return R_FAIL;
}


static RETURNV Main_CloseAll(void)
{
	log_info("Cleaning resources...");
	log_flush();
	if(window) SDL_DestroyWindow(window);
	Image_FreeAll();
	Object_CleanAll();
	Fish_FreeAll();
	SDL_Quit();
	
	log_info("All cleaning done.");
	log_flush();
	log_end();
	return R_SUCCESS;
}
