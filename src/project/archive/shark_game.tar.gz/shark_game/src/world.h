
#ifndef PH_SRC__WORLD_H__
#define PH_SRC__WORLD_H__

#include "image.h"
#include "object.h"
#include "global_def.h"

#define WORLD_WIDTH 800
#define WORLD_HEIGHT 400

// handy utility for objects to use in their update functions
#define update_sprite_position(o) (o)->edata.image.world_position.x=(int)((o)->edata.pos.x)+o->edata.sprite_offset_x;\
(o)->edata.image.world_position.y=(int)((o)->edata.pos.y)+o->edata.sprite_offset_y

struct world_data_s {
	GameClass_t *player;
	
	GameClass_t *fish_array;
	int *fish_array_active;
	size_t fish_array_head;
	
	int max_fish;
	int fish_count;
	
	int player_score;
	
	int ticks;
	
	int total_entity_count;
};


RETURNV World_SpawnPlayer(World_t *world, int sx, int sy);
GameClass_t *World_GetPlayer(World_t *world);

RETURNV World_SpawnFish(World_t *world, int sy, const char *fish_type);

RETURNV World_GetEntityList(World_t *world, GameClass_t **list_pointer, int **active_flags, 
	int *entity_count);

RETURNV World_Create(World_t *target, int max_fish);
RETURNV World_Destroy(World_t *target);


RETURNV World_BeginFrame(World_t *target);
RETURNV World_GetScoreAsArray(int num, int *array_out, int max_digits);

#endif