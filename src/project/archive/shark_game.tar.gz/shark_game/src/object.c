#include "object.h"
#include "ashare/dbg.h"

#include <stdlib.h>

// temporary names list, used in Class definitions, before Object_LoadClasses()
static char **CLASS_NAMES_ST;
// array of functions to initialise all Classes pushed for loading
static RETURNV (*load_class[CLASS_MAX])(void);
// final names list, initialised in ObjectL_LoadClasses(), never* changes
static char **CLASS_NAMES = NULL;

// keeps track of how many classes and names we have
static int class_load_counter = 0;
// this actually doubles as our overall class counter!
static int class_name_counter = 0;

// when this is 1, we've loaded classes and no more can be added
static int obj_started = 0;
// used to assign unique IDs
static int obj_id_counter = 0;

/**
	Object_Alloc(int count)
		RETURNS: pointer to a GameClass_t struct, fully* allocated
	This function exists in case we want some fancier pooled memory management
	 for objects in the future. Could be changed to a macro?
*/
GameClass_t *Object_Alloc(int count)
{
	GameClass_t *out = calloc(sizeof(GameClass_t), count);
	check(out, "Could not allocate for Object.");
	return out;
error:
	return NULL;
}


/**
	Object_Free(GameClass_t *target)
	
	Companion to Object_Alloc. Just a placeholder for if we do memory
	 differently later. Could also become a macro, moreso than _Alloc
	 because the final behaviour might be simpler.
*/
RETURNV Object_Free(GameClass_t *target)
{
	if(target) {
		free(target);
		return R_SUCCESS;
	}
	else {
		return R_FATAL;
	}
}

/**
	Object_Create(GameClass_t *target, GameClass_t proto, ...)
		
	Actually creates and allocates an Object at target. Target should be NULL,
	 but we don't force that in case it's part of an array/memory block.
	This function copies all of the function pointers and some metadata from
	 the Class prototype (proto), which is hopefully accessed via automatic
	 name generation by a macro. Don't call this directly, use Object_New()!
*/
RETURNV Object_Create(GameClass_t *target, GameClass_t proto, ...)
{
	
	check(target != NULL, "Attempting to create an object that is NULL, please preallocate.");
		
	check(&proto != NULL, "Trying to load from invalid Class prototype!");
	debug("Prototype is valid, creating Object of Class: %s", Object_GetClassString(proto.type));
	debug_flush();
	target->type = proto.type;
	Object_Setup(target, proto);
	
	#ifdef CF_CHECK_STRICT
	check(target->hInit_f != NULL, 
		"Failed to setup Object INIT function - Class:%s", 
		Object_GetClassString(target->type));
		
	check(target->hUpdate_f,
		"Failed to setup Object UPDATE function - Class:%s", 
		Object_GetClassString(target->type));
		
	check(target->hAnim_f,
		"Failed to setup Object ANIM function - Class:%s", 
		Object_GetClassString(target->type));
	
	check(target->hLogDump_f,
		"Failed to setup Object LOG function - Class:%s",
		Object_GetClassString(target->type));
		
	check(target->hCollides_f,
		"Failed to setup Object COLLISION function - Class:%s",
		Object_GetClassString(target->type));
		
	#endif
	//debug("Getting UID.");
	target->id = Object_GetUID();
	check(target->id >= 0, "Could not generate a proper ID for object!");
	//log_info("Ready to call Init function handle.");
	
	va_list ap;
	va_start(ap, proto);
	RETURNV rv = target->hInit_f(target, ap);
	va_end(ap);
	
	check(rv != R_FAIL, "Failed to initialise Object - Class: %s, ID: %d", 
		Object_GetClassString(target->type), target->id);
	
	return R_SUCCESS;
error:
	log_warn("Could not create object of Class %s", Object_GetClassString(proto.type));
	return R_FAIL;
	
}


/**
	Object_PushLoadForClass(class_load_fn fun)
		
	Parameter is a function pointer, but this function is handled automatically in
	 the CLASS_DEFINE block, so you never need to specifically worry about it.
	All this does is add a function to the load_class array, which is then called
	 when we decide we're ready to actually load the classes and call Object_LoadClasses()
*/
RETURNV Object_PushLoadForClass(class_load_fn func)
{
	check(obj_started == 0, "Object systems have started, cannot set new class for loading.");
	check( func != NULL, "Function given for Class loading was NULL." );
	load_class[class_load_counter++] = func;
	return R_SUCCESS;
error:
	return R_FAIL;
}

/**
	Object_AssignClassID(const char *class_name)
		- RETURNS: OBJDEF_TYPE (numerical Class ID)
	Takes the name of a class in exchange for the class identifier token.
	The user never needs to know this is a number, and it doesn't even need to be.
	The String can be recalled using the value returned, in Object_GetClassString(type)
*/
OBJDEF_TYPE Object_AssignClassID(const char *class_name)
{
	check(obj_started == 0, "Object systems have started, cannot get new Class type no.");
	check( class_name != NULL, "Given name for class was NULL.");
	
	log_info("Assigning class ID - Class: %s, ID: %d", class_name, class_name_counter);
	// we need to copy the string
	size_t name_len = strlen(class_name);
	CLASS_NAMES_ST[class_name_counter] = malloc( name_len * sizeof(char) );
	// use strncpy without checking name_len is valid
	strcpy(CLASS_NAMES_ST[class_name_counter], class_name);
	// remember to increment this counter because it's important
	OBJDEF_TYPE out = class_name_counter++;
	return out;
error:
	return CLASS_ID_ERR;
}


/**
	Object_LoadClasses()
		- RETURNS: flag for success or failure
	Iterates through the functions in load_class, and calls them to setup the
	 Class prototype structs. Then, iterates through our temporary array for
	 Class names and copies them to a new array of exact size.
	After this function is called, obj_started is set to 1. This stops new 
	 classes being able to be defined. Push all Classes for loading before
	 calling this function in main()!
*/
RETURNV Object_LoadClasses(void)
{
	check(obj_started == 0, "Cannot load classes if the Object system has started.");
	int i;
	
	log_info("Loading Class data from export functions...");
	// these FOR loops check i against different values
	//  we could/should check that these are the same?
	for( i = 0; i < class_load_counter; i++ ) {
		int rc = load_class[i]();
		check(rc == R_SUCCESS, "Failed to load a Class!");
	}
	
	CLASS_NAMES = calloc( class_name_counter, sizeof(char *) );
	log_info("Memory allocated for Class Name array, temp String count: %d", class_name_counter);
	for( i = 0; i < class_name_counter; i++ ) {
		CLASS_NAMES[i] = CLASS_NAMES_ST[i];
		log_info("Copying class name: %s", CLASS_NAMES[i]);
	}
	free(CLASS_NAMES_ST);
	
	log_info("Object system started.");
	obj_started = 1;
	return R_SUCCESS;
error:
	return R_FAIL;
}


/**
	Object_GetClassString(OBJDEF_TYPE class_type)
		- RETURNS: a pointer to string data, NULL terminated
	Checks if Object_LoadClasses has been called, and get a Class string by ID from
	 one of two arrays.
*/
const char *Object_GetClassString(OBJDEF_TYPE class_type)
{
	// make sure this is a valid type
	check(class_type >= 0 && class_type < class_name_counter, "Invalid class id:%d", class_type);
	const char *out = NULL;
	// if obj_started is 0 we read from the temporary list
	if(obj_started == 0) {
		out = CLASS_NAMES_ST[class_type];
	}
	else {
		out = CLASS_NAMES[class_type];
	}
	
	check(out != NULL, "Bad Class name string, id:%d.", class_type);
	return out;
error:
	return NULL;
}


/**
	Object_GetUID()
		- RETURNS: unique ID
	Assigns a unique ID to an Object, called at creation. The counter also serves as
	 an overall count for all Objects created.
*/
OBJDEF_ID Object_GetUID()
{
	return( obj_id_counter++ );
}


/**
	Object_Begin()
		- RETURNS: flag for success or failure
	Called in main() before any other Object_* functions. Needed to setup the memory
	 for Class name storage in Windows CL compiler apparently. Either way, it's safer
	 to have this defined and used as a standard if we _do_ need important housekeeping
	 here in the future.
*/
RETURNV Object_Begin(void)
{
	CLASS_NAMES_ST = calloc(CLASS_MAX, sizeof(char*));
	check_mem(CLASS_NAMES_ST);
	return R_SUCCESS;
error:
	return R_FAIL;
}


/**
	Object_CleanAll()
	
	Called to cleanup any memory used by the Object systems, notably String data.
*/
RETURNV Object_CleanAll(void)
{
	char **names_list = NULL;
	int i;
	// read from the temporary list (_ST) if obj_started is not 1
	names_list = ( obj_started == 1 )? CLASS_NAMES : CLASS_NAMES_ST;
	log_info("Cleaning String data for Object classes.");
	debug_flush();
	
	check(names_list != NULL, "Class name list is invalid!");
	for( i = 0; i < class_name_counter; i++ ) {
		if(names_list[i]) free(names_list[i]);
	}
	
	free(names_list);
	log_info("Class String memory released.");
	return R_SUCCESS;
error:
	return R_FAIL;
}
