#include <windows.h>
#include <stdlib.h>

#include "ashare\dbg.h"
#include "ashare\share_base.h"
#include "object.h"
#include "class\tester.h"
#include "global_def.h"


//int WINAPI WinMain(HINSTANCE hI, HINSTANCE hPrev, LPSTR lpCmdLine, int CmdShow)
int main(int argc, char *argv[])
{
	log_init("startup.log", "w");
	log_info("Starting up.");
	RETURNV rv = 0;
	
	rv = Object_Begin();
	check(rv == R_SUCCESS, "Object pre-load initialisation failed.");
	CLASS_SETLOAD(Tester);
	log_flush();
	
	
	rv = Object_LoadClasses();
	check( rv == R_SUCCESS, "Failed to load classes!");
	log_info("Done.");
	log_end();
	log_init("run.log", "w");
	
	//log_end();
	//log_init("run.log", "w");
	log_info("Do thing.");
	log_flush();
	GameClass_t *obj = Object_Alloc(1);
	int num1 =5, num2 =6, num3 =7, num4 =1, num5 =77;
	rv = Object_New(obj, Tester, VLIST(&num1, &num2, &num3, &num4, &num5) );
	debug_flush();
	check(rv == R_SUCCESS && obj != NULL, "Failed to create Object. Return: %s", RV_STRING(rv));
	log_info("Successfully created a new Object of class %s.", Object_GetClassString(obj->type));
	debug_flush();
	rv = object_update(obj, &num1);
	check(rv == R_SUCCESS, "Could not update Object.");
	log_info("All done, it works!");
	debug_flush();
	Object_CleanAll();
	log_end();
	
	return R_SUCCESS;
error:
	return R_FAIL;
}