
# Shark Game

Code by Tom Marks 2016. Updated for release Jan 2024.

This code was halfway through a refactor, I was implementing
a "fish sequencer" in `seq.c` apparently. The goal was to
load waves of fish that were hand coded, I think? It didn't
work so I ripped the references to it out of `game.c`, all of
my old testing code for spawning in fish manually using the
number keys still works.

This "game" is provided with no documentation. Read the code
to work out what is up.

I implemented my own terrible object system in C here. Apparently
I have always hated C++.

Enjoy? And good luck :D

